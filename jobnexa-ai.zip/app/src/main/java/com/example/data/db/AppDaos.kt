package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Application
import com.example.data.model.AuditLog
import com.example.data.model.CandidateProfile
import com.example.data.model.EmployerMessage
import com.example.data.model.Job
import com.example.data.model.JobMatch
import com.example.data.model.JobSource
import com.example.data.model.OfferReview
import kotlinx.coroutines.flow.Flow

@Dao
interface CandidateDao {
    @Query("SELECT * FROM candidate_profiles WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<CandidateProfile?>

    @Query("SELECT * FROM candidate_profiles WHERE id = 1 LIMIT 1")
    suspend fun getProfileSync(): CandidateProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: CandidateProfile)

    @Update
    suspend fun updateProfile(profile: CandidateProfile)
}

@Dao
interface JobDao {
    @Query("SELECT * FROM jobs ORDER BY publicationDate DESC")
    fun getAllJobs(): Flow<List<Job>>

    @Query("SELECT * FROM jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJobById(jobId: String): Job?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(jobs: List<Job>)

    @Query("SELECT COUNT(*) FROM jobs")
    suspend fun getJobCount(): Int
}

@Dao
interface JobMatchDao {
    @Query("SELECT * FROM job_matches ORDER BY overallScore DESC")
    fun getAllMatches(): Flow<List<JobMatch>>

    @Query("SELECT * FROM job_matches WHERE jobId = :jobId LIMIT 1")
    fun getMatchForJob(jobId: String): Flow<JobMatch?>

    @Query("SELECT * FROM job_matches WHERE jobId = :jobId LIMIT 1")
    suspend fun getMatchForJobSync(jobId: String): JobMatch?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatches(matches: List<JobMatch>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMatch(match: JobMatch)

    @Query("UPDATE job_matches SET isSaved = :saved WHERE id = :id")
    suspend fun updateSavedStatus(id: String, saved: Boolean)
}

@Dao
interface ApplicationDao {
    @Query("SELECT * FROM applications ORDER BY appliedTimestamp DESC")
    fun getAllApplications(): Flow<List<Application>>

    @Query("SELECT * FROM applications WHERE id = :id LIMIT 1")
    suspend fun getApplicationById(id: String): Application?

    @Query("SELECT * FROM applications WHERE jobId = :jobId LIMIT 1")
    suspend fun getApplicationByJobId(jobId: String): Application?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApplication(application: Application)

    @Update
    suspend fun updateApplication(application: Application)

    @Query("UPDATE applications SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("UPDATE applications SET candidateApproved = :approved, status = :status WHERE id = :id")
    suspend fun approveAndSubmit(id: String, approved: Boolean, status: String)

    @Query("SELECT COUNT(*) FROM applications WHERE appliedTimestamp >= :startOfDayTimestamp")
    suspend fun countApplicationsToday(startOfDayTimestamp: Long): Int
}

@Dao
interface EmployerMessageDao {
    @Query("SELECT * FROM employer_messages ORDER BY id DESC")
    fun getAllMessages(): Flow<List<EmployerMessage>>

    @Query("SELECT * FROM employer_messages WHERE category = 'INTERVIEW_INVITATION' ORDER BY id DESC")
    fun getInterviewInvitations(): Flow<List<EmployerMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: EmployerMessage)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<EmployerMessage>)

    @Query("UPDATE employer_messages SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)
}

@Dao
interface OfferReviewDao {
    @Query("SELECT * FROM offer_reviews ORDER BY reviewedTimestamp DESC")
    fun getAllOfferReviews(): Flow<List<OfferReview>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOfferReview(review: OfferReview)
}

@Dao
interface JobSourceDao {
    @Query("SELECT * FROM job_sources ORDER BY region ASC, name ASC")
    fun getAllSources(): Flow<List<JobSource>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSources(sources: List<JobSource>)

    @Query("UPDATE job_sources SET latencyMs = :latency, lastSyncTime = :syncTime, totalVacanciesIndexed = :count WHERE id = :id")
    suspend fun updateSyncStats(id: String, latency: Int, syncTime: String, count: Int)

    @Query("UPDATE job_sources SET authConfigured = :configured WHERE id = :id")
    suspend fun updateAuthConfigured(id: String, configured: Boolean)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLog)

    @Query("DELETE FROM audit_logs")
    suspend fun clearLogs()
}
