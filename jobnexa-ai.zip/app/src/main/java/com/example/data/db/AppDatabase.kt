package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Application
import com.example.data.model.AuditLog
import com.example.data.model.CandidateProfile
import com.example.data.model.EmployerMessage
import com.example.data.model.Job
import com.example.data.model.JobMatch
import com.example.data.model.JobSource
import com.example.data.model.OfferReview

@Database(
    entities = [
        CandidateProfile::class,
        Job::class,
        JobMatch::class,
        Application::class,
        EmployerMessage::class,
        OfferReview::class,
        JobSource::class,
        AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun candidateDao(): CandidateDao
    abstract fun jobDao(): JobDao
    abstract fun jobMatchDao(): JobMatchDao
    abstract fun applicationDao(): ApplicationDao
    abstract fun employerMessageDao(): EmployerMessageDao
    abstract fun offerReviewDao(): OfferReviewDao
    abstract fun jobSourceDao(): JobSourceDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "globalhire_ai_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
