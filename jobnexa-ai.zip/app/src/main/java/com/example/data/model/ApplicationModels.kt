package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "applications")
data class Application(
    @PrimaryKey val id: String,
    val jobId: String,
    val jobTitle: String,
    val company: String,
    val country: String,
    val city: String,
    val salaryDisplay: String,
    val status: String,
    // Status states:
    // Discovered -> Match Reviewed -> Eligible for Application -> Application Prepared ->
    // Awaiting Candidate Approval -> Submitted -> Employer Response -> Interview ->
    // Offer Received -> Contract Verification -> Visa Process -> Closed
    val appliedTimestamp: Long,
    val tailoredCvContent: String,
    val tailoredCoverLetter: String,
    val submissionMethod: String, // "Official Partner API", "Guided Portal Assistant"
    val submissionReferenceId: String?,
    val candidateApproved: Boolean,
    val portalDirectUrl: String?,
    val candidateNotes: String = ""
)

@Entity(tableName = "employer_messages")
data class EmployerMessage(
    @PrimaryKey val id: String,
    val applicationId: String,
    val company: String,
    val roleTitle: String,
    val senderName: String,
    val senderEmail: String,
    val receivedDate: String,
    val category: String, // INTERVIEW_INVITATION, OFFER_LETTER, INFO_REQUEST, ASSESSMENT, REJECTION
    val subject: String,
    val bodySnippet: String,
    val interviewDate: String? = null,
    val interviewTimezone: String? = null,
    val interviewLink: String? = null,
    val interviewFormat: String? = null, // "Technical Round via Teams", "Video Panel via Google Meet"
    val requiresAction: Boolean = false,
    val isRead: Boolean = false
)

@Entity(tableName = "offer_reviews")
data class OfferReview(
    @PrimaryKey val id: String,
    val applicationId: String?,
    val companyName: String,
    val roleTitle: String,
    val country: String,
    val monthlyGrossOffered: Double,
    val currency: String,
    val contractType: String, // "Permanent", "2-Year Fixed Term"
    val uploadedDocumentName: String,
    val verificationOutcome: String, // "AUTHENTIC_VERIFIED", "WARNING_UNVERIFIED_FEES", "SUSPICIOUS_DETAILS"
    val riskScore: Int, // 0 = safe, 100 = high risk
    val officialRegistryCheck: String,
    val feePolicyNotice: String,
    val keyTermsSummary: String,
    val recommendedActions: String,
    val reviewedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "job_sources")
data class JobSource(
    @PrimaryKey val id: String,
    val name: String,
    val region: String, // "European Union", "Gulf Cooperation Council", "Global"
    val type: String, // "EURES Gateway", "National Employment Agency", "Verified API Feed"
    val status: String, // "ONLINE", "HEALTHY_FEED", "CREDENTIALS_NEEDED", "DEGRADED"
    val officialWebsiteUrl: String,
    val latencyMs: Int,
    val totalVacanciesIndexed: Int,
    val lastSyncTime: String,
    val requiresExternalAuth: Boolean,
    val authConfigured: Boolean,
    val description: String
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionType: String,
    val category: String, // "AI_EXTRACTION", "VISA_ENGINE", "APPLICATION_PIPELINE", "GDPR_PRIVACY", "INTEGRATION_SYNC"
    val description: String,
    val status: String // "SUCCESS", "INFO", "WARNING", "FAILED"
)
