package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "candidate_profiles")
data class CandidateProfile(
    @PrimaryKey val id: Int = 1,
    val fullName: String = "Alex Mercer",
    val email: String = "alex.mercer@jobnexa.ai",
    val phone: String = "+44 7700 900123",
    val citizenship: String = "India",
    val currentResidenceCountry: String = "United Kingdom",
    val currentPermitStatus: String = "Graduate Route Visa (Tier 4 Extension)",
    val ageRange: String = "26-35",
    val educationLevel: String = "Bachelor of Science",
    val fieldOfStudy: String = "Mechanical & Industrial Automation Engineering",
    val yearsExperience: Int = 6,
    val currentJobTitle: String = "Senior Automation & Heavy Equipment Specialist",
    val responsibilities: String = "Operating and troubleshooting CNC milling machines, Siemens PLC systems, and heavy hydraulic excavators. Leading site safety compliance and machinery maintenance protocols.",
    val primaryIndustry: String = "Engineering & Advanced Manufacturing",
    val machineEquipment: String = "CAT 320 Excavator, Siemens S7-1500 PLC, Haas 5-Axis CNC, Komatsu WA380",
    val licences: String = "EU Code 95 Professional Driver, TÜV Welder ISO 9606-1, OSHA 30 Industrial Safety",
    val licenceIssuingCountry: String = "Germany & United Kingdom",
    val languages: String = "English (C1 - Fluent), German (B1 - Intermediate), Arabic (A2 - Elementary)",
    val preferredCountries: String = "Germany, Netherlands, Poland, Saudi Arabia, UAE, Sweden",
    val preferredCities: String = "Munich, Amsterdam, Warsaw, Riyadh, Dubai, Stockholm",
    val expectedSalaryMonthly: Double = 4800.0,
    val currency: String = "EUR",
    val willingToRelocate: Boolean = true,
    val accommodationRequired: Boolean = false,
    val availabilityDate: String = "Within 30 Days",
    val cvFileName: String = "Alex_Mercer_CV_2026.pdf",
    val cvRawText: String = "",
    val cvDocumentUrl: String = "",
    val userId: String = "sandbox_candidate_default",
    val introVideoUrl: String = "https://jobnexa.ai/profiles/alex-intro.mp4",
    val consentAccepted: Boolean = true,
    val autoApplicationEnabled: Boolean = false,
    val maxApplicationsPerDay: Int = 5,
    val excludedEmployers: String = "PreviousCo Ltd",
    val updatedAt: Long = System.currentTimeMillis()
)
