package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jobs")
data class Job(
    @PrimaryKey val id: String,
    val title: String,
    val company: String,
    val country: String,
    val city: String,
    val sourceName: String, // e.g. "EURES Official", "BA Germany", "GulfTalent Gateway", "France Travail"
    val sourceUrl: String,
    val publicationDate: String,
    val employmentType: String, // Full-time, Permanent
    val grossSalaryMonthly: Double,
    val currency: String,
    val minYearsExperience: Int,
    val requiredQualifications: String,
    val requiredLicences: String,
    val requiredLanguages: String,
    val sponsorshipStatus: String, // "Verified Sponsor", "Sponsorship Available", "Unverified", "No Sponsorship"
    val applicationMethod: String, // "API_DIRECT", "PORTAL_GUIDED", "AUTHORIZED_PARTNER"
    val verificationStatus: String, // "VERIFIED_OFFICIAL", "REVIEWED", "PENDING_CHECK"
    val description: String,
    val visaTrack: String,
    val officialVisaSource: String,
    val officialVisaUrl: String,
    val estimatedLivingCostMonthly: Double,
    val estimatedTaxRate: Double // e.g. 0.32 for 32%
)

@Entity(tableName = "job_matches")
data class JobMatch(
    @PrimaryKey val id: String, // usually matches jobId
    val jobId: String,
    val overallScore: Int, // 0 - 100
    val skillScore: Int,
    val experienceScore: Int,
    val licenceScore: Int,
    val languageScore: Int,
    val visaScore: Int,
    val salaryScore: Int,
    val visaTrackSummary: String,
    val recognitionRequired: Boolean,
    val recognitionAuthority: String,
    val licenceEquivalenceNote: String,
    val grossSalary: Double,
    val estimatedNetSalary: Double,
    val estimatedLivingCost: Double,
    val estimatedMonthlySavings: Double,
    val currency: String,
    val matchExplanation: String,
    val isSaved: Boolean = false,
    val calculatedAt: Long = System.currentTimeMillis()
)
