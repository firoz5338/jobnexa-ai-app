package com.example.data.remote.jobs

import com.example.data.model.Job

sealed class ProviderResult<out T> {
    data class Success<T>(val data: T, val totalAvailable: Int, val source: String) : ProviderResult<T>()
    data class Error(val message: String, val statusCode: Int? = null) : ProviderResult<Nothing>()
    object RateLimited : ProviderResult<Nothing>()
    object UnconfiguredCredentials : ProviderResult<Nothing>()
}

data class ProviderGatewayInfo(
    val id: String,
    val name: String,
    val region: String,
    val website: String,
    val authType: String,
    val isConfigured: Boolean,
    val statusText: String,
    val vacanciesCount: Int
)

interface JobProvider {
    val providerId: String
    val providerName: String
    val region: String
    val officialWebsite: String
    val requiresCredentials: Boolean

    fun isConfigured(): Boolean
    suspend fun fetchJobs(query: String? = null, country: String? = null, limit: Int = 20): ProviderResult<List<Job>>
}
