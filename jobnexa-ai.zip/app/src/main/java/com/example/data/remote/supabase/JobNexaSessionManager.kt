package com.example.data.remote.supabase

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AuthState {
    object Unauthenticated : AuthState()
    data class Authenticated(
        val user: AuthUser,
        val accessToken: String,
        val isCloudSyncActive: Boolean
    ) : AuthState()
    data class SandboxDemo(
        val user: AuthUser
    ) : AuthState()
}

class JobNexaSessionManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("jobnexa_auth_session", Context.MODE_PRIVATE)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Unauthenticated)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        restoreSession()
    }

    fun restoreSession() {
        val isSandbox = prefs.getBoolean(KEY_IS_SANDBOX, false)
        if (isSandbox) {
            val user = AuthUser(
                id = prefs.getString(KEY_USER_ID, "sandbox_candidate_001") ?: "sandbox_candidate_001",
                email = prefs.getString(KEY_USER_EMAIL, "alex.mercer@jobnexa.ai") ?: "alex.mercer@jobnexa.ai",
                role = "sandbox_demo"
            )
            _authState.value = AuthState.SandboxDemo(user)
            return
        }

        val token = prefs.getString(KEY_ACCESS_TOKEN, "") ?: ""
        val userId = prefs.getString(KEY_USER_ID, "") ?: ""
        val email = prefs.getString(KEY_USER_EMAIL, "") ?: ""

        if (token.isNotBlank() && userId.isNotBlank()) {
            val user = AuthUser(
                id = userId,
                email = email,
                role = "authenticated"
            )
            _authState.value = AuthState.Authenticated(
                user = user,
                accessToken = token,
                isCloudSyncActive = SupabaseConfig.isConfigured(context)
            )
        } else {
            // Default to Sandbox Demo for instant local preview while preserving explicit sign-in option
            val user = AuthUser(
                id = "sandbox_candidate_001",
                email = "alex.mercer@jobnexa.ai",
                role = "sandbox_demo"
            )
            _authState.value = AuthState.SandboxDemo(user)
        }
    }

    fun setAuthenticatedSession(session: AuthSession) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, session.access_token)
            .putString(KEY_REFRESH_TOKEN, session.refresh_token)
            .putString(KEY_USER_ID, session.user.id)
            .putString(KEY_USER_EMAIL, session.user.email)
            .putBoolean(KEY_IS_SANDBOX, false)
            .apply()

        _authState.value = AuthState.Authenticated(
            user = session.user,
            accessToken = session.access_token,
            isCloudSyncActive = true
        )
    }

    fun enterSandboxDemoMode() {
        val user = AuthUser(
            id = "sandbox_candidate_001",
            email = "alex.mercer@jobnexa.ai",
            role = "sandbox_demo"
        )
        prefs.edit()
            .putBoolean(KEY_IS_SANDBOX, true)
            .putString(KEY_USER_ID, user.id)
            .putString(KEY_USER_EMAIL, user.email)
            .remove(KEY_ACCESS_TOKEN)
            .apply()

        _authState.value = AuthState.SandboxDemo(user)
    }

    fun logOut() {
        prefs.edit()
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_USER_ID)
            .remove(KEY_USER_EMAIL)
            .putBoolean(KEY_IS_SANDBOX, false)
            .apply()

        _authState.value = AuthState.Unauthenticated
    }

    fun getCurrentUserId(): String {
        return when (val state = _authState.value) {
            is AuthState.Authenticated -> state.user.id
            is AuthState.SandboxDemo -> state.user.id
            is AuthState.Unauthenticated -> ""
        }
    }

    fun getCurrentUserEmail(): String {
        return when (val state = _authState.value) {
            is AuthState.Authenticated -> state.user.email
            is AuthState.SandboxDemo -> state.user.email
            is AuthState.Unauthenticated -> ""
        }
    }

    companion object {
        private const val KEY_ACCESS_TOKEN = "jwt_access_token"
        private const val KEY_REFRESH_TOKEN = "jwt_refresh_token"
        private const val KEY_USER_ID = "auth_user_id"
        private const val KEY_USER_EMAIL = "auth_user_email"
        private const val KEY_IS_SANDBOX = "is_sandbox_mode"
    }
}
