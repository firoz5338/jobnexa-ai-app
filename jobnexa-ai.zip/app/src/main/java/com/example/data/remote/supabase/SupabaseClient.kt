package com.example.data.remote.supabase

import android.content.Context
import com.example.data.model.Application as JobApplication
import com.example.data.model.CandidateProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class SupabaseClient(private val context: Context) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getBaseUrl(): String {
        return SupabaseConfig.getSupabaseUrl(context).trimEnd('/')
    }

    private fun getAnonKey(): String {
        return SupabaseConfig.getSupabaseAnonKey(context)
    }

    suspend fun pingHealth(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context)) {
            return@withContext Pair(false, "Supabase credentials are not configured.")
        }
        val startTime = System.currentTimeMillis()
        val url = "${getBaseUrl()}/rest/v1/"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .get()
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val elapsed = System.currentTimeMillis() - startTime
                if (response.isSuccessful || response.code == 200 || response.code == 404) {
                    Pair(true, "Connected to Supabase PostgreSQL in ${elapsed}ms (HTTP ${response.code})")
                } else {
                    Pair(false, "Supabase returned HTTP ${response.code}: ${response.message}")
                }
            }
        } catch (e: Exception) {
            Pair(false, "Connection error: ${e.localizedMessage ?: "Network failure"}")
        }
    }

    suspend fun signUp(email: String, password: String, fullName: String): AuthResult<AuthSession> = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context)) {
            return@withContext AuthResult.Error("Cloud Backend is not configured. Provide Supabase URL and Anon Key in Settings.")
        }

        val json = JSONObject().apply {
            put("email", email.trim())
            put("password", password)
            put("data", JSONObject().apply {
                put("full_name", fullName.trim())
            })
        }

        val url = "${getBaseUrl()}/auth/v1/signup"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Content-Type", "application/json")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()

        executeAuthRequest(request)
    }

    suspend fun signIn(email: String, password: String): AuthResult<AuthSession> = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context)) {
            return@withContext AuthResult.Error("Cloud Backend is not configured. Provide Supabase URL and Anon Key in Settings.")
        }

        val json = JSONObject().apply {
            put("email", email.trim())
            put("password", password)
        }

        val url = "${getBaseUrl()}/auth/v1/token?grant_type=password"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Content-Type", "application/json")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()

        executeAuthRequest(request)
    }

    suspend fun recoverPassword(email: String): AuthResult<String> = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context)) {
            return@withContext AuthResult.Error("Cloud Backend is not configured.")
        }

        val json = JSONObject().apply {
            put("email", email.trim())
        }

        val url = "${getBaseUrl()}/auth/v1/recover"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Content-Type", "application/json")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    AuthResult.Success("Password recovery instructions dispatched to ${email.trim()}.")
                } else {
                    val errorMsg = parseErrorMessage(body, "Password recovery request failed (HTTP ${response.code}).")
                    AuthResult.Error(errorMsg, response.code)
                }
            }
        } catch (e: Exception) {
            AuthResult.Error("Network error: ${e.localizedMessage}")
        }
    }

    suspend fun signOut(accessToken: String): Boolean = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context) || accessToken.isBlank()) return@withContext true

        val url = "${getBaseUrl()}/auth/v1/logout"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Authorization", "Bearer $accessToken")
            .post("{}".toRequestBody(jsonMediaType))
            .build()

        try {
            httpClient.newCall(request).execute().use { it.isSuccessful }
        } catch (_: Exception) {
            true // Local logout still succeeds
        }
    }

    suspend fun syncProfileToCloud(accessToken: String, profile: CandidateProfile, userId: String): Boolean = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context) || accessToken.isBlank()) return@withContext false

        val json = JSONObject().apply {
            put("id", userId)
            put("full_name", profile.fullName)
            put("email", profile.email)
            put("phone", profile.phone)
            put("citizenship", profile.citizenship)
            put("current_residence_country", profile.currentResidenceCountry)
            put("current_permit_status", profile.currentPermitStatus)
            put("age_range", profile.ageRange)
            put("education_level", profile.educationLevel)
            put("field_of_study", profile.fieldOfStudy)
            put("years_experience", profile.yearsExperience)
            put("current_job_title", profile.currentJobTitle)
            put("responsibilities", profile.responsibilities)
            put("primary_industry", profile.primaryIndustry)
            put("machine_equipment", profile.machineEquipment)
            put("licences", profile.licences)
            put("licence_issuing_country", profile.licenceIssuingCountry)
            put("languages", profile.languages)
            put("preferred_countries", profile.preferredCountries)
            put("preferred_cities", profile.preferredCities)
            put("expected_salary_monthly", profile.expectedSalaryMonthly)
            put("currency", profile.currency)
            put("willing_to_relocate", profile.willingToRelocate)
            put("accommodation_required", profile.accommodationRequired)
            put("availability_date", profile.availabilityDate)
            put("cv_file_name", profile.cvFileName)
            put("cv_raw_text", profile.cvRawText)
            put("intro_video_url", profile.introVideoUrl ?: "")
            put("consent_accepted", profile.consentAccepted)
            put("auto_application_enabled", profile.autoApplicationEnabled)
            put("max_applications_per_day", profile.maxApplicationsPerDay)
        }

        val url = "${getBaseUrl()}/rest/v1/candidate_profiles?on_conflict=id"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-duplicates,return=representation")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                response.isSuccessful || response.code == 201 || response.code == 200
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun saveApplicationToCloud(
        accessToken: String,
        userId: String,
        app: JobApplication
    ): Boolean = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context) || accessToken.isBlank()) return@withContext false
        val url = "${getBaseUrl()}/rest/v1/candidate_applications"
        val json = JSONObject().apply {
            put("id", app.id)
            put("user_id", userId)
            put("job_id", app.jobId)
            put("job_title", app.jobTitle)
            put("company", app.company)
            put("country", app.country)
            put("city", app.city)
            put("salary_display", app.salaryDisplay)
            put("status", app.status)
            put("applied_timestamp", app.appliedTimestamp)
            put("tailored_cv_content", app.tailoredCvContent)
            put("tailored_cover_letter", app.tailoredCoverLetter)
            put("submission_method", app.submissionMethod)
            put("submission_reference_id", app.submissionReferenceId)
            put("candidate_approved", app.candidateApproved)
            put("portal_direct_url", app.portalDirectUrl)
            put("candidate_notes", app.candidateNotes)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Prefer", "resolution=merge-duplicates")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                response.isSuccessful || response.code == 201 || response.code == 200
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun uploadCvDocument(
        accessToken: String,
        userId: String,
        fileName: String,
        bytes: ByteArray,
        mimeType: String = "application/pdf"
    ): StorageUploadResult = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context)) {
            return@withContext StorageUploadResult.Error("Cloud Backend is not configured.")
        }
        if (bytes.size > 10 * 1024 * 1024) {
            return@withContext StorageUploadResult.Error("File exceeds the 10 MB maximum upload limit.")
        }
        if (!fileName.endsWith(".pdf", ignoreCase = true) && !fileName.endsWith(".docx", ignoreCase = true)) {
            return@withContext StorageUploadResult.Error("Invalid file type. Only PDF and DOCX documents are permitted.")
        }

        val sanitizedName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val storagePath = "$userId/$sanitizedName"
        val url = "${getBaseUrl()}/storage/v1/object/candidate_documents/$storagePath"

        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("x-upsert", "true")
            .post(bytes.toRequestBody(mimeType.toMediaType()))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    StorageUploadResult.Success(
                        path = storagePath,
                        fullStorageUrl = "$url (Protected by Row Level Security)"
                    )
                } else {
                    val body = response.body?.string() ?: ""
                    StorageUploadResult.Error("Upload failed (HTTP ${response.code}): $body")
                }
            }
        } catch (e: Exception) {
            StorageUploadResult.Error("Storage network error: ${e.localizedMessage}")
        }
    }

    suspend fun getSignedCvUrl(
        accessToken: String,
        storagePath: String,
        expiresInSeconds: Int = 300
    ): String? = withContext(Dispatchers.IO) {
        if (!SupabaseConfig.isConfigured(context) || accessToken.isBlank()) return@withContext null

        val json = JSONObject().apply {
            put("expiresIn", expiresInSeconds)
        }
        val url = "${getBaseUrl()}/storage/v1/object/sign/candidate_documents/$storagePath"

        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@use null
                    val jsonObj = JSONObject(body)
                    val signedPath = jsonObj.optString("signedURL", "")
                    if (signedPath.isNotBlank()) {
                        "${getBaseUrl()}/storage/v1$signedPath"
                    } else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun executeAuthRequest(request: Request): AuthResult<AuthSession> {
        return try {
            httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val session = parseAuthSession(body)
                    if (session != null) {
                        AuthResult.Success(session)
                    } else {
                        AuthResult.Error("Failed to parse authenticated session payload.")
                    }
                } else {
                    val errorMsg = parseErrorMessage(body, "Authentication request failed (HTTP ${response.code}).")
                    AuthResult.Error(errorMsg, response.code)
                }
            }
        } catch (e: IOException) {
            AuthResult.Error("Network failure connecting to Supabase: ${e.localizedMessage}")
        } catch (e: Exception) {
            AuthResult.Error("Unexpected authentication error: ${e.localizedMessage}")
        }
    }

    private fun parseAuthSession(body: String): AuthSession? {
        return try {
            val json = JSONObject(body)
            val accessToken = json.optString("access_token", "")
            val tokenType = json.optString("token_type", "bearer")
            val expiresIn = json.optLong("expires_in", 3600L)
            val refreshToken = json.optString("refresh_token", "")

            val userObj = json.optJSONObject("user") ?: return null
            val userId = userObj.getString("id")
            val email = userObj.optString("email", "")
            val role = userObj.optString("role", "authenticated")

            val metadataMap = mutableMapOf<String, Any?>()
            val metaObj = userObj.optJSONObject("user_metadata")
            metaObj?.keys()?.forEach { k ->
                metadataMap[k] = metaObj.opt(k)
            }

            AuthSession(
                access_token = accessToken,
                token_type = tokenType,
                expires_in = expiresIn,
                refresh_token = refreshToken,
                user = AuthUser(
                    id = userId,
                    email = email,
                    role = role,
                    user_metadata = metadataMap
                )
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parseErrorMessage(body: String, fallback: String): String {
        return try {
            val json = JSONObject(body)
            when {
                json.has("error_description") -> json.getString("error_description")
                json.has("msg") -> json.getString("msg")
                json.has("message") -> json.getString("message")
                json.has("error") -> json.getString("error")
                else -> fallback
            }
        } catch (_: Exception) {
            fallback
        }
    }
}
