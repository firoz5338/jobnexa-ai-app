package com.example.data.remote.supabase

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

object SupabaseConfig {

    private const val PREFS_NAME = "jobnexa_supabase_prefs"
    private const val KEY_CUSTOM_URL = "custom_supabase_url"
    private const val KEY_CUSTOM_KEY = "custom_supabase_anon_key"

    fun getSupabaseUrl(context: Context? = null): String {
        if (context != null) {
            val prefs = getPrefs(context)
            val customUrl = prefs.getString(KEY_CUSTOM_URL, "")?.trim() ?: ""
            if (customUrl.isNotBlank()) return customUrl
        }

        val buildUrl = try {
            BuildConfig.SUPABASE_URL.trim()
        } catch (_: Exception) {
            ""
        }
        return if (isValidUrl(buildUrl)) buildUrl else ""
    }

    fun getSupabaseAnonKey(context: Context? = null): String {
        if (context != null) {
            val prefs = getPrefs(context)
            val customKey = prefs.getString(KEY_CUSTOM_KEY, "")?.trim() ?: ""
            if (customKey.isNotBlank()) return customKey
        }

        val buildKey = try {
            BuildConfig.SUPABASE_ANON_KEY.trim()
        } catch (_: Exception) {
            ""
        }
        return if (isValidKey(buildKey)) buildKey else ""
    }

    fun isConfigured(context: Context? = null): Boolean {
        val url = getSupabaseUrl(context)
        val key = getSupabaseAnonKey(context)
        return isValidUrl(url) && isValidKey(key)
    }

    fun saveCustomCredentials(context: Context, url: String, anonKey: String) {
        getPrefs(context).edit()
            .putString(KEY_CUSTOM_URL, url.trim())
            .putString(KEY_CUSTOM_KEY, anonKey.trim())
            .apply()
    }

    fun clearCustomCredentials(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_CUSTOM_URL)
            .remove(KEY_CUSTOM_KEY)
            .apply()
    }

    private fun isValidUrl(url: String): Boolean {
        return url.startsWith("https://") && !url.contains("your-project-id") && url.contains(".supabase.co")
    }

    private fun isValidKey(key: String): Boolean {
        return key.length > 20 && !key.contains("your-supabase-anon")
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
}
