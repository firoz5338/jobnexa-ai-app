package com.example.data.remote.supabase

data class AuthUser(
    val id: String,
    val email: String,
    val role: String? = null,
    val user_metadata: Map<String, Any?>? = null
)

data class AuthSession(
    val access_token: String,
    val token_type: String,
    val expires_in: Long,
    val refresh_token: String,
    val user: AuthUser
)

sealed class AuthResult<out T> {
    data class Success<out T>(val data: T) : AuthResult<T>()
    data class Error(val message: String, val statusCode: Int? = null) : AuthResult<Nothing>()
}

data class SignedUrlResponse(
    val signedURL: String
)

sealed class StorageUploadResult {
    data class Success(val path: String, val fullStorageUrl: String) : StorageUploadResult()
    data class Error(val message: String) : StorageUploadResult()
}
