package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Job
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaCyan
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate900
import com.example.ui.viewmodel.JobRegions

data class FinancialBreakdown(
    val grossSalaryMonthly: Double,
    val currency: String,
    val isGulf: Boolean,
    val taxRatePercent: Int,
    val taxAmountMonthly: Double,
    val foodHousingStatus: String,
    val isHousingFree: Boolean,
    val estimatedLivingCostMonthly: Double,
    val estimatedNetMonthlySavings: Double,
    val visaRelocationCostWorker: Double,
    val savingsHighlight: String,
    val visaTrackLabel: String,
    val antiScamNote: String
)

object BlueCollarJobHelper {

    fun getRoleMachineryIcon(title: String): String {
        val lower = title.lowercase()
        return when {
            lower.contains("excavator") || lower.contains("bulldozer") || lower.contains("dozer") || lower.contains("earthmoving") || lower.contains("grader") || lower.contains("loader") -> "🚜"
            lower.contains("crane") || lower.contains("rigging") || lower.contains("rigger") || lower.contains("hoist") -> "🏗️"
            lower.contains("haul truck") || lower.contains("mining") || lower.contains("truck") || lower.contains("transport") -> "🚚"
            lower.contains("mechanic") || lower.contains("hydraulic") || lower.contains("plant") || lower.contains("fitter") || lower.contains("diesel") -> "🔧"
            lower.contains("welder") || lower.contains("welding") || lower.contains("pipe") || lower.contains("fabricat") -> "🛠️"
            lower.contains("technician") || lower.contains("cnc") || lower.contains("mechatronics") || lower.contains("machining") -> "⚙️"
            else -> "⚡"
        }
    }

    fun getCountryFlag(country: String): String {
        return when (country.lowercase().trim()) {
            "germany" -> "🇩🇪"
            "netherlands" -> "🇳🇱"
            "poland" -> "🇵🇱"
            "sweden" -> "🇸🇪"
            "austria" -> "🇦🇹"
            "united kingdom", "uk" -> "🇬🇧"
            "saudi arabia" -> "🇸🇦"
            "united arab emirates", "uae" -> "🇦🇪"
            "qatar" -> "🇶🇦"
            "oman" -> "🇴🇲"
            "kuwait" -> "🇰🇼"
            "bahrain" -> "🇧🇭"
            else -> "🌐"
        }
    }

    fun calculateFinancialBreakdown(job: Job): FinancialBreakdown {
        val isGulf = JobRegions.isGulf(job.country)
        val gross = job.grossSalaryMonthly

        if (isGulf) {
            val taxRate = 0
            val taxAmount = 0.0
            val livingDeduction = 250.0 // Small incidental/pocket expenses
            val estimatedNetSavings = (gross - livingDeduction).coerceAtLeast(gross * 0.88)
            val visaLabel = when {
                job.country.contains("Saudi", true) -> "🇸🇦 Qiwa Free Iqama & Visa"
                job.country.contains("Qatar", true) -> "🇶🇦 QVC Free Visa & Medical"
                else -> "🇦🇪 MoHRE Free Resident Visa"
            }
            return FinancialBreakdown(
                grossSalaryMonthly = gross,
                currency = job.currency,
                isGulf = true,
                taxRatePercent = taxRate,
                taxAmountMonthly = taxAmount,
                foodHousingStatus = "Free Single AC Room + 3 Meals Provided (100% Employer Paid)",
                isHousingFree = true,
                estimatedLivingCostMonthly = 0.0,
                estimatedNetMonthlySavings = estimatedNetSavings,
                visaRelocationCostWorker = 0.0,
                savingsHighlight = "Save ~${job.currency} ${estimatedNetSavings.toInt()}/mo (0% Tax + Free Camp & Food)",
                visaTrackLabel = visaLabel,
                antiScamNote = "By Gulf Labor Law, all visa fees, medical tests, and air tickets are 100% paid by the employer. Never pay any recruitment agent."
            )
        } else {
            val taxRate = when (job.country.lowercase().trim()) {
                "germany" -> 32
                "netherlands" -> 34
                "poland" -> 20
                "sweden" -> 30
                "austria" -> 30
                else -> 25
            }
            val taxAmount = gross * (taxRate / 100.0)
            val livingCost = if (job.estimatedLivingCostMonthly > 0) job.estimatedLivingCostMonthly else 1350.0
            val estimatedNetSavings = (gross - taxAmount - livingCost).coerceAtLeast(600.0)
            val visaLabel = "${getCountryFlag(job.country)} ${job.visaTrack.ifBlank { "EU Blue Card / Work Permit" }}"
            return FinancialBreakdown(
                grossSalaryMonthly = gross,
                currency = job.currency,
                isGulf = false,
                taxRatePercent = taxRate,
                taxAmountMonthly = taxAmount,
                foodHousingStatus = "Standard Local Rent & Living Costs (~${job.currency} ${livingCost.toInt()}/mo)",
                isHousingFree = false,
                estimatedLivingCostMonthly = livingCost,
                estimatedNetMonthlySavings = estimatedNetSavings,
                visaRelocationCostWorker = 0.0,
                savingsHighlight = "Save ~${job.currency} ${estimatedNetSavings.toInt()}/mo (Net after EU tax & living)",
                visaTrackLabel = visaLabel,
                antiScamNote = "Direct European employer sponsorship under official EU labor directives. Direct apply only."
            )
        }
    }
}

@Composable
fun AntiFraudBanner(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF0F1E36),
        border = BorderStroke(1.dp, Color(0xFF1E355B)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("anti_fraud_banner")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = EmeraldContainer,
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield",
                        tint = EmeraldSuccess,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Anti-Fraud Guard",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = EmeraldSuccess
                    ) {
                        Text(
                            text = "100% FREE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 9.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Direct employer apply only. Never pay upfront fees for visas or job offers.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate400,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "View Details",
                tint = JobNexaCyan,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun AntiFraudDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "JobNexa Anti-Fraud Guarantee",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = JobNexaNavy
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = EmeraldContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ZERO Recruitment Fees for Workers",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                    }
                }

                Text(
                    text = "1. Gulf Labor Laws (Saudi Qiwa, UAE MoHRE, Qatar QVC) mandate that employers must pay 100% of visa, medical examination, and flight costs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate900,
                    lineHeight = 18.sp
                )

                Text(
                    text = "2. European Union Directives prohibit charging jobseekers for job placement or work permit applications.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate900,
                    lineHeight = 18.sp
                )

                Text(
                    text = "3. Every vacancy on JobNexa AI links directly to official employer career portals (e.g. NEOM, BAM, Strabag, Siemens, ASML) without middleman recruiters.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate900,
                    lineHeight = 18.sp
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate100,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "⚠️ Warning: If anyone contacts you requesting money, gift cards, or crypto for visa processing, DO NOT PAY. Report them immediately.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(10.dp),
                        lineHeight = 16.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("dismiss_anti_fraud_dialog_button")
            ) {
                Text("Understood & Protected")
            }
        }
    )
}
