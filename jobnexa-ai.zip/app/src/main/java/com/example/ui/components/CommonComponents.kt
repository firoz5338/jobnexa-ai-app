package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.CoralContainer
import com.example.ui.theme.CoralError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NavyDark
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import kotlin.math.roundToInt

fun getCountryFlagEmoji(country: String): String {
    return when (country.lowercase().trim()) {
        "germany" -> "🇩🇪"
        "netherlands" -> "🇳🇱"
        "poland" -> "🇵🇱"
        "saudi arabia" -> "🇸🇦"
        "united arab emirates", "uae" -> "🇦🇪"
        "qatar" -> "🇶🇦"
        "austria" -> "🇦🇹"
        "sweden" -> "🇸🇪"
        "france" -> "🇫🇷"
        "ireland" -> "🇮🇪"
        "norway" -> "🇳🇴"
        "finland" -> "🇫🇮"
        "denmark" -> "🇩🇰"
        "czechia" -> "🇨🇿"
        "belgium" -> "🇧🇪"
        "spain" -> "🇪🇸"
        "portugal" -> "🇵🇹"
        "italy" -> "🇮🇹"
        "kuwait" -> "🇰🇼"
        "bahrain" -> "🇧🇭"
        "oman" -> "🇴🇲"
        "india" -> "🇮🇳"
        "united kingdom", "uk" -> "🇬🇧"
        "pakistan" -> "🇵🇰"
        else -> "🌍"
    }
}

@Composable
fun MatchScoreBadge(score: Int, modifier: Modifier = Modifier) {
    val (bg, fg) = when {
        score >= 85 -> Pair(EmeraldContainer, EmeraldSuccess)
        score >= 70 -> Pair(SkyBlueContainer, SkyBluePrimary)
        else -> Pair(AmberContainer, AmberAccent)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$score%",
                color = fg,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "MATCH",
                color = fg.copy(alpha = 0.8f),
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun SponsorshipBadge(status: String, modifier: Modifier = Modifier) {
    val isVerified = status.contains("Verified", ignoreCase = true)
    val (bgColor, textColor, icon) = if (isVerified) {
        Triple(EmeraldContainer, EmeraldSuccess, Icons.Default.Verified)
    } else {
        Triple(SkyBlueContainer, SkyBluePrimary, Icons.Default.CheckCircle)
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = status,
            tint = textColor,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = status,
            color = textColor,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp
        )
    }
}

@Composable
fun StatusPill(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, icon) = when (status) {
        "Interview" -> Triple(EmeraldContainer, EmeraldSuccess, Icons.Default.CheckCircle)
        "Submitted" -> Triple(SkyBlueContainer, SkyBluePrimary, Icons.Default.CheckCircle)
        "Application Prepared", "Awaiting Candidate Approval" -> Triple(AmberContainer, AmberAccent, Icons.Default.Warning)
        "Offer Received" -> Triple(Color(0xFFEDE9FE), Color(0xFF7C3AED), Icons.Default.Verified)
        "Contract Verification", "Visa Process" -> Triple(Color(0xFFFEF3C7), Color(0xFFD97706), Icons.Default.Info)
        "Closed" -> Triple(CoralContainer, CoralError, Icons.Default.Info)
        else -> Triple(Color(0xFFE2E8F0), Slate700, Icons.Default.Info)
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = status,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun CostOfLivingBreakdownCard(
    gross: Double,
    net: Double,
    livingCost: Double,
    savings: Double,
    currency: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Financial & Net Savings Projection",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ESTIMATED",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Gross -> Net -> Living -> Savings
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FinancialMetricCol(title = "Gross Salary", amount = "€${gross.roundToInt()}", color = MaterialTheme.colorScheme.onSurface)
                FinancialMetricCol(title = "Est. Net", amount = "€${net.roundToInt()}", color = SkyBlueLight)
                FinancialMetricCol(title = "Living Cost", amount = "-€${livingCost.roundToInt()}", color = CoralError)
                FinancialMetricCol(title = "Monthly Savings", amount = "+€${savings.roundToInt()}", color = EmeraldSuccess)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Visual bar
            val total = maxOf(1.0, gross)
            val netRatio = (net / total).toFloat().coerceIn(0f, 1f)
            val savingsRatio = (savings / total).toFloat().coerceIn(0f, 1f)

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Disposable Savings Share", style = MaterialTheme.typography.bodySmall, color = Slate400)
                    Text("${(savingsRatio * 100).roundToInt()}% of gross", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { savingsRatio },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = EmeraldSuccess,
                    trackColor = Slate700
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Disclaimer: Projections are indicative based on destination standard tax brackets and city average living cost indices (Numbeo/OECD 2026 data). Actual contractual take-home is determined upon formal offer.",
                style = MaterialTheme.typography.labelSmall,
                color = Slate400,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
private fun FinancialMetricCol(title: String, amount: String, color: Color) {
    Column {
        Text(title, style = MaterialTheme.typography.labelSmall, color = Slate400)
        Text(amount, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (badge != null) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = badge,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
        }
        if (subtitle != null) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Slate400
            )
        }
    }
}

@Composable
fun EmptyStateView(
    icon: ImageVector,
    title: String,
    message: String,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.size(64.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = Slate400,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        if (actionText != null && onAction != null) {
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(
                onClick = onAction,
                modifier = Modifier.testTag("empty_state_action_button")
            ) {
                Text(actionText)
            }
        }
    }
}
