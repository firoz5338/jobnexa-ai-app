package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaCyan
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.JobNexaNavyBorder
import com.example.ui.theme.Slate400

@Composable
fun JobNexaSymbol(
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    isDarkBg: Boolean = true
) {
    val navyBg = JobNexaNavy
    val cyanColor = JobNexaCyan
    val blueColor = JobNexaAiBlue
    val sparkColor = if (isDarkBg) Color.White else JobNexaCyan

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(if (isDarkBg) navyBg else Color(0xFF0F1E36))
            .border(1.dp, JobNexaNavyBorder, RoundedCornerShape(size * 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.75f)) {
            val w = this.size.width
            val h = this.size.height

            // 1. Globe Orbital Arc
            drawArc(
                color = blueColor,
                startAngle = 100f,
                sweepAngle = 230f,
                useCenter = false,
                topLeft = Offset(w * 0.12f, h * 0.15f),
                size = Size(w * 0.76f, h * 0.72f),
                style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
            )

            // 2. Latitude ring
            drawArc(
                color = blueColor.copy(alpha = 0.5f),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(w * 0.18f, h * 0.35f),
                size = Size(w * 0.64f, h * 0.45f),
                style = Stroke(width = w * 0.05f, cap = StrokeCap.Round)
            )

            // 3. Dynamic Forward Mobility Arrow (Electric Cyan #54D9F5)
            val arrowPath = Path().apply {
                moveTo(w * 0.28f, h * 0.72f)
                lineTo(w * 0.58f, h * 0.44f)
                lineTo(w * 0.50f, h * 0.42f)
                lineTo(w * 0.76f, h * 0.24f)
                lineTo(w * 0.72f, h * 0.52f)
                lineTo(w * 0.64f, h * 0.44f)
                lineTo(w * 0.38f, h * 0.76f)
                close()
            }
            drawPath(arrowPath, color = cyanColor)

            // Arrow head
            val arrowHead = Path().apply {
                moveTo(w * 0.58f, h * 0.22f)
                lineTo(w * 0.82f, h * 0.22f)
                lineTo(w * 0.82f, h * 0.46f)
                lineTo(w * 0.74f, h * 0.38f)
                lineTo(w * 0.66f, h * 0.30f)
                close()
            }
            drawPath(arrowHead, color = cyanColor)

            // 4. AI Spark / North Star Beacon
            val sparkPath = Path().apply {
                val cx = w * 0.84f
                val cy = h * 0.18f
                val r = w * 0.11f
                val ir = w * 0.035f

                moveTo(cx, cy - r)
                lineTo(cx + ir, cy - ir)
                lineTo(cx + r, cy)
                lineTo(cx + ir, cy + ir)
                lineTo(cx, cy + r)
                lineTo(cx - ir, cy + ir)
                lineTo(cx - r, cy)
                lineTo(cx - ir, cy - ir)
                close()
            }
            drawPath(sparkPath, color = sparkColor)
        }
    }
}

@Composable
fun JobNexaBrandHeader(
    modifier: Modifier = Modifier,
    symbolSize: Dp = 34.dp,
    titleSize: TextUnit = 17.sp,
    showTagline: Boolean = true,
    taglineText: String = "Your AI Agent for Global Jobs"
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        JobNexaSymbol(size = symbolSize)
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "JobNexa",
                    fontSize = titleSize,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = (-0.3).sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "AI",
                    fontSize = titleSize,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif,
                    color = JobNexaCyan,
                    letterSpacing = (-0.3).sp
                )
            }
            if (showTagline) {
                Text(
                    text = taglineText,
                    style = MaterialTheme.typography.labelSmall,
                    color = Slate400,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
