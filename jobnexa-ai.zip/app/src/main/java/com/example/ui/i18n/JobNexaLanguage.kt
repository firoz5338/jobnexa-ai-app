package com.example.ui.i18n

enum class AppLanguage(
    val code: String,
    val englishName: String,
    val nativeName: String,
    val isRtl: Boolean
) {
    ENGLISH("en", "English", "English", false);

    companion object {
        fun fromCode(code: String): AppLanguage = ENGLISH
    }
}

object JobNexaStrings {
    fun navHome(lang: AppLanguage = AppLanguage.ENGLISH): String = "Home"
    fun navSearch(lang: AppLanguage = AppLanguage.ENGLISH): String = "Search Jobs"
    fun navApplications(lang: AppLanguage = AppLanguage.ENGLISH): String = "My Applications"
    fun navProfile(lang: AppLanguage = AppLanguage.ENGLISH): String = "Profile"
    fun signIn(lang: AppLanguage = AppLanguage.ENGLISH): String = "Sign In"
    fun signUp(lang: AppLanguage = AppLanguage.ENGLISH): String = "Sign Up"
    fun signOut(lang: AppLanguage = AppLanguage.ENGLISH): String = "Sign Out"
    fun searchPlaceholder(lang: AppLanguage = AppLanguage.ENGLISH): String = "Search job titles, skills, or employers..."
    fun verifiedVacanciesTitle(lang: AppLanguage = AppLanguage.ENGLISH): String = "Verified International Vacancies"
    fun viewJob(lang: AppLanguage = AppLanguage.ENGLISH): String = "View Job"
    fun applyNow(lang: AppLanguage = AppLanguage.ENGLISH): String = "Apply Now"
    fun uploadCv(lang: AppLanguage = AppLanguage.ENGLISH): String = "Upload CV"
    fun uploadCvSubtitle(lang: AppLanguage = AppLanguage.ENGLISH): String = "Upload PDF or Word document (Max 10MB)"
    fun parseCvWithAi(lang: AppLanguage = AppLanguage.ENGLISH): String = "AI CV Parsing"
    fun allCountries(lang: AppLanguage = AppLanguage.ENGLISH): String = "All Countries"
    fun visaSponsorshipOnly(lang: AppLanguage = AppLanguage.ENGLISH): String = "Visa Sponsorship Only"
    fun monthlySalary(lang: AppLanguage = AppLanguage.ENGLISH): String = "Monthly Salary"
    fun location(lang: AppLanguage = AppLanguage.ENGLISH): String = "Location"
    fun officialSource(lang: AppLanguage = AppLanguage.ENGLISH): String = "Source"
    fun translateDescription(lang: AppLanguage = AppLanguage.ENGLISH): String = "Translate"
    fun showOriginal(lang: AppLanguage = AppLanguage.ENGLISH): String = "Show Original"
    fun devDiagnostics(lang: AppLanguage = AppLanguage.ENGLISH): String = "System Diagnostics"
    fun noApplicationsYet(lang: AppLanguage = AppLanguage.ENGLISH): String = "No applications yet"
    fun findJobsPrompt(lang: AppLanguage = AppLanguage.ENGLISH): String = "Explore verified vacancies and start your global career journey."
    fun signInRequiredToApply(lang: AppLanguage = AppLanguage.ENGLISH): String = "Please sign in or create an account to apply for this position."
    fun externalEmployerNotice(lang: AppLanguage = AppLanguage.ENGLISH): String = "This employer accepts applications directly on their official careers site."
    fun openOfficialPortal(lang: AppLanguage = AppLanguage.ENGLISH): String = "Open Official Employer Website"
}
