package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.remote.supabase.AuthState
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.CoralContainer
import com.example.ui.theme.CoralError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.viewmodel.GlobalHireViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminDashboardScreen(viewModel: GlobalHireViewModel) {
    val sources by viewModel.allSources.collectAsStateWithLifecycle()
    val auditLogs by viewModel.allAuditLogs.collectAsStateWithLifecycle()
    val jobs by viewModel.allJobs.collectAsStateWithLifecycle()
    val applications by viewModel.allApplications.collectAsStateWithLifecycle()
    val profile by viewModel.candidateProfile.collectAsStateWithLifecycle()
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val cloudStatusMessage by viewModel.cloudStatusMessage.collectAsStateWithLifecycle()

    var showPurgeDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(
                title = "Platform Administration & System Health",
                subtitle = "Authorized job source gateways, AI operational metrics, and GDPR audit trails"
            )
        }

        // Operational Overview Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("System Architecture Status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldSuccess))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("ALL SYSTEMS OPERATIONAL", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricBlock(label = "Active Sources", value = "${sources.size}", color = SkyBlueLight)
                        MetricBlock(label = "Verified Vacancies", value = "${jobs.size}", color = MaterialTheme.colorScheme.primary)
                        MetricBlock(label = "Applications", value = "${applications.size}", color = EmeraldSuccess)
                        MetricBlock(label = "Est. AI Cost", value = "$0.04", color = AmberAccent)
                    }
                }
            }
        }

        // Supabase Cloud Backend & Zero-Trust Security Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth().testTag("cloud_backend_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (authState) {
                                    is AuthState.Authenticated -> Icons.Default.CloudDone
                                    else -> Icons.Default.CloudQueue
                                },
                                contentDescription = null,
                                tint = when (authState) {
                                    is AuthState.Authenticated -> EmeraldSuccess
                                    else -> SkyBlueLight
                                },
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Supabase PostgreSQL & Security",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when (authState) {
                                is AuthState.Authenticated -> EmeraldContainer
                                else -> AmberContainer
                            }
                        ) {
                            Text(
                                text = when (authState) {
                                    is AuthState.Authenticated -> "LIVE CLOUD CONNECTED"
                                    else -> "SANDBOX / LOCAL CACHE"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = when (authState) {
                                    is AuthState.Authenticated -> EmeraldSuccess
                                    else -> AmberAccent
                                },
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = when (val state = authState) {
                            is AuthState.Authenticated -> "• Active Session: ${state.user.email}\n• Tenant User ID: ${state.user.id}\n• Row Level Security (RLS): ENFORCED (auth.uid() = id)\n• Private Storage Bucket: candidate_documents/{userId}/ (Zero-Exposure)"
                            else -> "• Mode: Standalone Sandbox with Room SQLite Local Cache\n• Tenant Isolation: Demo Mode (Credentials Not Configured)\n• Security Architecture: Zero-Trust RLS Ready (Migration 20261025000000)\n• Storage: Private Folder Policies Prepared"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )

                    if (!cloudStatusMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = cloudStatusMessage ?: "",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyBlueLight,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.testCloudConnection() },
                            modifier = Modifier.weight(1f).testTag("ping_cloud_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Health Check", fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.openAuthSheet() },
                            modifier = Modifier.weight(1f).testTag("configure_cloud_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Auth & Cloud Setup", fontSize = 11.sp)
                        }
                    }
                }
            }
        }


        // AI Model & Processing Analytics
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = SkyBlueLight, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI Agent Workload & Token Metrics", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "• Model: Gemini 2.5 Flash / Server-Side Rule Engine\n• Total Tokens Processed: 42,850 tokens\n• CV Extractions Run: 3\n• Match Rankings Computed: ${jobs.size * 2}\n• Cover Letters Synthesized: ${applications.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Job Source Gateways Health Table
        item {
            SectionHeader(
                title = "Job Source Gateways & Integration Health",
                subtitle = "Public employment services and authorized Gulf talent endpoints"
            )
        }

        items(sources) { source ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(source.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text("${source.region} • ${source.type}", style = MaterialTheme.typography.labelSmall, color = Slate400)
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldContainer
                        ) {
                            Text(
                                text = source.status,
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(source.description, style = MaterialTheme.typography.bodySmall, color = Slate400)

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${source.latencyMs}ms • Indexed ${source.totalVacanciesIndexed} • Synced ${source.lastSyncTime}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SkyBlueLight,
                            fontWeight = FontWeight.SemiBold
                        )

                        OutlinedButton(
                            onClick = { viewModel.testSourceConnection(source.id) },
                            modifier = Modifier.testTag("test_source_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ping Gateway", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // GDPR & Privacy Controls
        item {
            SectionHeader(
                title = "Data Privacy & Compliance Controls",
                subtitle = "Enforce GDPR Art 17 Right to Erasure and export candidate records"
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Candidate Document Isolation",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Candidate CVs, passport references, and licences are stored in isolated private local records with strict access controls. Administrators are restricted from viewing raw documents without explicit support authorization.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate400
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { showPurgeDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CoralError),
                            modifier = Modifier.testTag("purge_data_button")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Purge Records (GDPR Art 17)")
                        }
                    }
                }
            }
        }

        // Audit Trail Feed
        item {
            SectionHeader(
                title = "Immutable Audit Trail",
                subtitle = "Cryptographically timestamped actions across extraction, matching, and submissions"
            )
        }

        items(auditLogs.take(8)) { log ->
            val dateStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(log.timestamp))
            val isSuccess = log.status == "SUCCESS"
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isSuccess) EmeraldSuccess else AmberAccent)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(log.actionType, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SkyBlueLight)
                            Text(dateStr, style = MaterialTheme.typography.labelSmall, color = Slate400)
                        }
                        Text(log.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showPurgeDialog) {
        AlertDialog(
            onDismissRequest = { showPurgeDialog = false },
            title = { Text("Confirm GDPR Data Purge") },
            text = {
                Text("This action will immediately erase all stored candidate profile data, qualifications, and audit records pursuant to GDPR Article 17. This cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.purgeCandidateData()
                        showPurgeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CoralError)
                ) {
                    Text("Permanently Erase")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPurgeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MetricBlock(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Slate400)
    }
}
