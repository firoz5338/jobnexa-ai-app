package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forward
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Application as JobApp
import com.example.domain.ApplicationAutomationAgent
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.getCountryFlagEmoji
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.viewmodel.GlobalHireViewModel

@Composable
fun ApplicationPipelineScreen(viewModel: GlobalHireViewModel) {
    val applications by viewModel.allApplications.collectAsStateWithLifecycle()
    val selectedAppForDetail by viewModel.selectedApplicationForDetail.collectAsStateWithLifecycle()

    var selectedStageFilter by remember { mutableStateOf("All") }
    val stages = listOf("All", "Awaiting Approval", "Submitted", "Interview", "Closed")

    val filteredApps = when (selectedStageFilter) {
        "Awaiting Approval" -> applications.filter { it.status == "Awaiting Candidate Approval" || it.status == "Application Prepared" }
        "Submitted" -> applications.filter { it.status == "Submitted" }
        "Interview" -> applications.filter { it.status == "Interview" }
        "Closed" -> applications.filter { it.status == "Closed" }
        else -> applications
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // State Machine Legend Bar
        SectionHeader(
            title = "International Application Pipeline",
            subtitle = "Candidate-authorized 12-stage mobility workflow"
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Stage Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(stages) { stage ->
                FilterChip(
                    selected = selectedStageFilter == stage,
                    onClick = { selectedStageFilter = stage },
                    label = { Text(stage) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredApps.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.Description,
                title = "No Applications in this Stage",
                message = "Find jobs in Job Discovery and tap 'Prepare Application with AI Agent' to generate candidate-approved application kits."
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredApps) { app ->
                    ApplicationCard(
                        app = app,
                        onViewDetails = { viewModel.openApplicationDetail(app) },
                        onQuickSubmit = { viewModel.approveAndSubmitApplication(app.id) },
                        onAdvanceStatus = { nextStatus -> viewModel.advanceApplicationStatus(app.id, nextStatus) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    // Detail Bottom Sheet if selected
    if (selectedAppForDetail != null) {
        ApplicationDetailBottomSheet(
            app = selectedAppForDetail!!,
            onDismiss = { viewModel.closeApplicationDetail() },
            onAuthorizeAndSubmit = { appId ->
                viewModel.approveAndSubmitApplication(appId)
            },
            onAdvanceStatus = { appId, status ->
                viewModel.advanceApplicationStatus(appId, status)
            }
        )
    }
}

@Composable
fun ApplicationCard(
    app: JobApp,
    onViewDetails: () -> Unit,
    onQuickSubmit: () -> Unit,
    onAdvanceStatus: (String) -> Unit
) {
    var showStatusMenu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onViewDetails() }
            .testTag("app_card_${app.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Flag + Location + Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(getCountryFlagEmoji(app.country), fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${app.city}, ${app.country}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                }
                StatusPill(status = app.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = app.jobTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${app.company} • ${app.salaryDisplay}",
                style = MaterialTheme.typography.bodySmall,
                color = SkyBlueLight,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Reference or submission info
            if (app.submissionReferenceId != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Text(
                        text = "Ref: ${app.submissionReferenceId}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Notes summary
            if (app.candidateNotes.isNotBlank()) {
                Text(
                    text = app.candidateNotes,
                    style = MaterialTheme.typography.labelSmall,
                    color = Slate400,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            HorizontalDivider(color = Slate700)
            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onViewDetails,
                    modifier = Modifier.testTag("view_application_materials_button")
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("View Dossier")
                }

                // If awaiting approval, prominent Authorize button!
                if (!app.candidateApproved && (app.status == "Awaiting Candidate Approval" || app.status == "Application Prepared")) {
                    Button(
                        onClick = onQuickSubmit,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        modifier = Modifier.testTag("approve_submit_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sign-off & Submit")
                    }
                } else {
                    Box {
                        OutlinedButton(onClick = { showStatusMenu = true }) {
                            Text("Step Stage")
                            Icon(Icons.Default.Forward, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                        DropdownMenu(
                            expanded = showStatusMenu,
                            onDismissRequest = { showStatusMenu = false }
                        ) {
                            ApplicationAutomationAgent.WORKFLOW_STAGES.forEach { stage ->
                                DropdownMenuItem(
                                    text = { Text(stage) },
                                    onClick = {
                                        onAdvanceStatus(stage)
                                        showStatusMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApplicationDetailBottomSheet(
    app: JobApp,
    onDismiss: () -> Unit,
    onAuthorizeAndSubmit: (String) -> Unit,
    onAdvanceStatus: (String, String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    var consentChecked by remember { mutableStateOf(app.candidateApproved) }
    var selectedTab by remember { mutableStateOf(0) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(app.company, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(app.jobTitle, style = MaterialTheme.typography.bodySmall, color = Slate400)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(status = app.status)
                Text(
                    text = "Method: ${app.submissionMethod}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SkyBlueLight,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sub-tabs: Tailored CV vs Cover Letter
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Tailored CV") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Cover Letter") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (selectedTab == 0) app.tailoredCvContent else app.tailoredCoverLetter,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Explicit Candidate Approval Gate
            if (!app.candidateApproved) {
                Surface(
                    color = AmberContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = AmberAccent, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Candidate Authorization Required",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = AmberAccent
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "JobNexa AI will never submit an application without your explicit review and sign-off. Verify factual accuracy of generated CV and cover letter above.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AmberAccent.copy(alpha = 0.9f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = consentChecked,
                                onCheckedChange = { consentChecked = it }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "I authorize submission of these materials to ${app.company}.",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = AmberAccent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        onAuthorizeAndSubmit(app.id)
                        onDismiss()
                    },
                    enabled = consentChecked,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("modal_approve_submit_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Authorize & Submit Application", fontWeight = FontWeight.Bold)
                }
            } else {
                Surface(
                    color = EmeraldContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Application Officially Authorized", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            Text("Reference ID: ${app.submissionReferenceId ?: "JN-VERIFIED"}", style = MaterialTheme.typography.bodySmall, color = EmeraldSuccess)
                        }
                    }
                }
            }

            if (app.portalDirectUrl != null) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(app.portalDirectUrl))
                        context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Visit Official Employer Career Portal")
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
