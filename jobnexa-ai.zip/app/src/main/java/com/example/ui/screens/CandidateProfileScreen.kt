package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CandidateProfile
import com.example.data.remote.supabase.AuthState
import com.example.domain.ExtractedCvData
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate900
import com.example.ui.viewmodel.GlobalHireViewModel

@Composable
fun CandidateProfileScreen(viewModel: GlobalHireViewModel) {
    val profileState by viewModel.candidateProfile.collectAsStateWithLifecycle()
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val signedCvUrl by viewModel.signedCvDownloadUrl.collectAsStateWithLifecycle()
    val cvDialogData by viewModel.cvExtractionDialogData.collectAsStateWithLifecycle()
    val isAiParsing by viewModel.aiExtractionLoading.collectAsStateWithLifecycle()
    val parsingMethodUsed by viewModel.cvParsingMethodUsed.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val isAuthenticated = authState is AuthState.Authenticated || authState is AuthState.SandboxDemo

    var uploadError by remember { mutableStateOf<String?>(null) }

    // Form fields
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var citizenship by remember { mutableStateOf("") }
    var currentCountry by remember { mutableStateOf("") }
    var preferredJobTitles by remember { mutableStateOf("") }
    var skills by remember { mutableStateOf("") }
    var preferredCountries by remember { mutableStateOf("") }
    var yearsExpText by remember { mutableStateOf("") }
    var educationLevel by remember { mutableStateOf("") }
    var fieldOfStudy by remember { mutableStateOf("") }
    var licences by remember { mutableStateOf("") }
    var expectedSalaryText by remember { mutableStateOf("") }

    LaunchedEffect(profileState) {
        profileState?.let { p ->
            fullName = p.fullName
            email = p.email
            phone = p.phone
            citizenship = p.citizenship
            currentCountry = p.currentResidenceCountry
            preferredJobTitles = p.currentJobTitle
            skills = p.machineEquipment
            preferredCountries = p.preferredCountries
            yearsExpText = p.yearsExperience.toString()
            educationLevel = p.educationLevel
            fieldOfStudy = p.fieldOfStudy
            licences = p.licences
            expectedSalaryText = p.expectedSalaryMonthly.toInt().toString()
        }
    }

    // Document Picker Launcher (PDF / DOCX <= 10MB)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val contentResolver = context.contentResolver
                val mimeType = contentResolver.getType(uri) ?: "application/pdf"
                val inputStream = contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes() ?: ByteArray(0)
                inputStream?.close()

                if (bytes.size > 10 * 1024 * 1024) {
                    uploadError = "File exceeds 10MB limit (${bytes.size / (1024 * 1024)} MB). Please select a smaller document."
                } else if (!mimeType.contains("pdf") && !mimeType.contains("word") && !mimeType.contains("officedocument") && !mimeType.contains("text")) {
                    uploadError = "Unsupported format ($mimeType). Only PDF and Word documents are permitted."
                } else {
                    uploadError = null
                    val fileName = "cv_${System.currentTimeMillis()}.pdf"
                    viewModel.uploadCvFile(fileName, bytes, mimeType)

                    // Extract text for AI parsing
                    val rawText = String(bytes.take(4000).toByteArray(), Charsets.UTF_8).filter { it.isLetterOrDigit() || it.isWhitespace() || it == '@' || it == '.' || it == '+' }
                    viewModel.parseCvDocument(rawText)
                }
            } catch (e: Exception) {
                uploadError = "Could not read file: ${e.message}"
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Profile",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = JobNexaNavy
            )
            Text(
                text = "Manage your verified profile, uploaded CV, and global career preferences",
                style = MaterialTheme.typography.bodySmall,
                color = Slate600
            )
        }

        if (!isAuthenticated) {
            // Require Login before displaying candidate profile controls
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth().testTag("profile_login_required_card")
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(52.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = JobNexaAiBlue, modifier = Modifier.size(26.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Sign in to Access Your Candidate Profile",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = JobNexaNavy
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Candidate profile controls, CV upload, and AI parsing require a secure authenticated session protected by Supabase Row Level Security.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.openSignIn() },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("profile_signin_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Sign In", fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.openSignUp() },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("profile_signup_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Create Account", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // Logged In Candidate Profile Controls

            // CARD 1: CV / Resume Upload & Private Storage
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth().testTag("cv_upload_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "CV & Resume Document",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = JobNexaNavy
                                )
                                Text(
                                    text = "Private cloud storage (candidate_documents bucket)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Slate600
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = EmeraldContainer
                            ) {
                                Text(
                                    text = "Zero-Trust RLS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val activeCvName = profileState?.cvFileName
                        if (!activeCvName.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = null, tint = JobNexaAiBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(activeCvName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = JobNexaNavy)
                                        Text("Stored in private candidate folder", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.requestSignedCvDownload(activeCvName) },
                                        modifier = Modifier.testTag("request_signed_url_button")
                                    ) {
                                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Expiring Link (5m)", fontSize = 11.sp)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        if (!signedCvUrl.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Signed Temporary URL: $signedCvUrl",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        if (uploadError != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = uploadError ?: "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        // Prominent Upload CV Button
                        Button(
                            onClick = { filePickerLauncher.launch("*/*") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("upload_cv_prominent_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isAiParsing) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Parsing Document with AI...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (activeCvName.isNullOrBlank()) "Upload CV / Resume (PDF / DOCX)" else "Replace CV Document",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            // CARD 2: Personal Information
            item {
                ProfileSectionCard(title = "1. Personal Information") {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Legal Name") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_input"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_email_input"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number (Optional)") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_phone_input"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = citizenship,
                            onValueChange = { citizenship = it },
                            label = { Text("Citizenship") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = currentCountry,
                            onValueChange = { currentCountry = it },
                            label = { Text("Country of Residence") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            }

            // CARD 3: Professional Experience & Target Roles
            item {
                ProfileSectionCard(title = "2. Machinery, Licences & Global Preferences") {
                    OutlinedTextField(
                        value = preferredJobTitles,
                        onValueChange = { preferredJobTitles = it },
                        label = { Text("Target Role(s)") },
                        placeholder = { Text("e.g. Heavy Excavator Operator, Bulldozer Driver, Crane Specialist") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_job_titles_input"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = skills,
                        onValueChange = { skills = it },
                        label = { Text("Equipment & Machinery Operated") },
                        placeholder = { Text("e.g. CAT 349/390, CAT D10/D11 Dozer, Liebherr R980, Komatsu PC1250, Tadano GR-1000") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_skills_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = yearsExpText,
                            onValueChange = { yearsExpText = it },
                            label = { Text("Years Experience") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = educationLevel,
                            onValueChange = { educationLevel = it },
                            label = { Text("Trade / Technical Cert") },
                            placeholder = { Text("e.g. Certified Plant Operator") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = preferredCountries,
                        onValueChange = { preferredCountries = it },
                        label = { Text("Target Countries") },
                        placeholder = { Text("e.g. Saudi Arabia, UAE, Qatar, Germany, Netherlands") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_countries_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = licences,
                        onValueChange = { licences = it },
                        label = { Text("Operator Licences & Safety Certifications") },
                        placeholder = { Text("e.g. Heavy Plant Operator Card, Mobile Crane License, CSCS/VCA Safety, TUV Certified") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_licences_input")
                    )
                }
            }


            // Save Profile Button
            item {
                Button(
                    onClick = {
                        val current = profileState ?: CandidateProfile()
                        val updated = current.copy(
                            fullName = fullName,
                            email = email,
                            phone = phone,
                            citizenship = citizenship,
                            currentResidenceCountry = currentCountry,
                            currentJobTitle = preferredJobTitles,
                            machineEquipment = skills,
                            yearsExperience = yearsExpText.toIntOrNull() ?: 3,
                            educationLevel = educationLevel,
                            fieldOfStudy = fieldOfStudy,
                            licences = licences,
                            preferredCountries = preferredCountries,
                            expectedSalaryMonthly = expectedSalaryText.toDoubleOrNull() ?: 4500.0,
                            updatedAt = System.currentTimeMillis()
                        )
                        viewModel.updateProfile(updated)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("save_profile_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = JobNexaAiBlue)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Candidate Profile", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // AI CV Extraction Confirmation Dialog
    if (cvDialogData != null) {
        val extracted = cvDialogData!!
        var editName by remember { mutableStateOf(extracted.fullName) }
        var editTitle by remember { mutableStateOf(extracted.currentJobTitle) }
        var editSkills by remember { mutableStateOf(extracted.machineEquipment) }
        var editLicences by remember { mutableStateOf(extracted.licences) }
        var editExperience by remember { mutableStateOf(extracted.yearsExperience.toString()) }

        AlertDialog(
            onDismissRequest = { viewModel.dismissCvDialog() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = JobNexaAiBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Extracted CV Details")
                }
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "Source: ${parsingMethodUsed ?: "AI Parser"}\nPlease review and correct any details before saving to your profile:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Candidate Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Job Title") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editSkills,
                        onValueChange = { editSkills = it },
                        label = { Text("Extracted Skills") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editLicences,
                        onValueChange = { editLicences = it },
                        label = { Text("Certifications / Licences") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editExperience,
                        onValueChange = { editExperience = it },
                        label = { Text("Years Experience") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val modified = extracted.copy(
                            fullName = editName,
                            currentJobTitle = editTitle,
                            machineEquipment = editSkills,
                            licences = editLicences,
                            yearsExperience = editExperience.toIntOrNull() ?: extracted.yearsExperience
                        )
                        viewModel.applyExtractedCvToProfile(modified)
                    },
                    modifier = Modifier.testTag("apply_extracted_cv_button")
                ) {
                    Text("Apply to Profile")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissCvDialog() }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProfileSectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Slate100),
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JobNexaNavy)
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}
