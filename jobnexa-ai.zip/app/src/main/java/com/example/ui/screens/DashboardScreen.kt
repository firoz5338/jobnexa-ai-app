package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Job
import com.example.data.model.JobMatch
import com.example.ui.components.MatchScoreBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.SponsorshipBadge
import com.example.ui.components.getCountryFlagEmoji
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NavyDark
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.viewmodel.GlobalHireViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun DashboardScreen(viewModel: GlobalHireViewModel) {
    val profile by viewModel.candidateProfile.collectAsStateWithLifecycle()
    val applications by viewModel.allApplications.collectAsStateWithLifecycle()
    val messages by viewModel.allMessages.collectAsStateWithLifecycle()
    val filteredJobs by viewModel.filteredJobs.collectAsStateWithLifecycle()
    val sources by viewModel.allSources.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val awaitingApprovalCount = applications.count { it.status == "Awaiting Candidate Approval" || it.status == "Application Prepared" }
    val submittedCount = applications.count { it.status == "Submitted" }
    val interviewCount = applications.count { it.status == "Interview" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Hero Welcome Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = getCountryFlagEmoji(profile?.citizenship ?: "India"),
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${profile?.citizenship ?: "International"} Citizen • ${profile?.currentResidenceCountry ?: "UK"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Slate400
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Welcome back, ${profile?.fullName ?: "Candidate"}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${profile?.currentJobTitle ?: "Specialist"} • ${profile?.yearsExperience ?: 0} Years Experience",
                        style = MaterialTheme.typography.bodySmall,
                        color = SkyBlueLight,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Find the right job. Navigate the right visa. Move forward.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate400
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Relocation Chips
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillChip(icon = Icons.Default.Public, text = "Target: Europe & Gulf")
                        PillChip(icon = Icons.Default.CheckCircle, text = "Verified Licences")
                    }
                }
            }
        }

        // Upcoming Interview Spotlight (If any exists)
        val interviewMsg = messages.firstOrNull { it.category == "INTERVIEW_INVITATION" }
        if (interviewMsg != null) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.VideoCall, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Upcoming Interview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                                    Text(interviewMsg.company, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = NavyDark)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldSuccess.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "ACTION REQUIRED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = interviewMsg.interviewDate ?: "Date confirmed in message",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Text(
                            text = interviewMsg.interviewFormat ?: "Online Video Technical Panel",
                            style = MaterialTheme.typography.bodySmall,
                            color = NavyDark.copy(alpha = 0.8f)
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (interviewMsg.interviewLink != null) {
                                Button(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(interviewMsg.interviewLink))
                                        context.startActivity(intent)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    modifier = Modifier.testTag("join_interview_button")
                                ) {
                                    Text("Open Teams Meeting", fontWeight = FontWeight.Bold)
                                }
                            }
                            OutlinedButton(
                                onClick = { viewModel.navigateTo(Screen.RESPONSES_AND_OFFERS) }
                            ) {
                                Text("View Details")
                            }
                        }
                    }
                }
            }
        }

        // Application Pipeline Stats Row
        item {
            SectionHeader(
                title = "Application Pipeline",
                subtitle = "Active candidate mobility workflow"
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PipelineStatCard(
                    modifier = Modifier.weight(1f),
                    count = awaitingApprovalCount,
                    label = "Awaiting Sign-off",
                    icon = Icons.Default.HourglassTop,
                    color = AmberAccent,
                    onClick = { viewModel.navigateTo(Screen.APPLICATIONS_PIPELINE) }
                )
                PipelineStatCard(
                    modifier = Modifier.weight(1f),
                    count = submittedCount,
                    label = "Submitted",
                    icon = Icons.Default.Send,
                    color = SkyBluePrimary,
                    onClick = { viewModel.navigateTo(Screen.APPLICATIONS_PIPELINE) }
                )
                PipelineStatCard(
                    modifier = Modifier.weight(1f),
                    count = interviewCount,
                    label = "Interviews",
                    icon = Icons.Default.VideoCall,
                    color = EmeraldSuccess,
                    onClick = { viewModel.navigateTo(Screen.RESPONSES_AND_OFFERS) }
                )
            }
        }

        // Top Recommended Matches
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Top AI Job Matches",
                    subtitle = "Ranked by qualifications and work visa feasibility",
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "See All (${filteredJobs.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { viewModel.navigateTo(Screen.JOB_DISCOVERY) }
                        .padding(start = 8.dp)
                )
            }
        }

        items(filteredJobs.take(3)) { (job, match) ->
            JobCardItem(
                job = job,
                match = match,
                onClick = { viewModel.openJobDetail(job) },
                onToggleSave = { viewModel.toggleSaveJob(job.id, match?.isSaved == true) }
            )
        }

        // Job Source Gateway Live Status Strip
        item {
            SectionHeader(
                title = "Authorized Source Feeds",
                subtitle = "Live synchronization with European and Gulf employment agencies"
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(sources) { source ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.width(220.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(source.region, style = MaterialTheme.typography.labelSmall, color = Slate400)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldSuccess)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ONLINE", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(source.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, maxLines = 1)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${source.latencyMs}ms latency • synced ${source.lastSyncTime}", style = MaterialTheme.typography.labelSmall, color = Slate400)
                        }
                    }
                }
            }
        }

        // Bottom Spacer for navigation bar
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun JobCardItem(
    job: Job,
    match: JobMatch?,
    onClick: () -> Unit,
    onToggleSave: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("job_card_${job.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Location & Flag + Match Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = getCountryFlagEmoji(job.country), fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${job.city}, ${job.country}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Slate400
                    )
                }
                if (match != null) {
                    MatchScoreBadge(score = match.overallScore)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Job Title
            Text(
                text = job.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Company & Source
            Text(
                text = "${job.company} • Via ${job.sourceName}",
                style = MaterialTheme.typography.bodySmall,
                color = SkyBlueLight,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Badges Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SponsorshipBadge(status = job.sponsorshipStatus)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Text(
                        text = "€${job.grossSalaryMonthly.toInt()} / mo",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                if (match != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = EmeraldContainer
                    ) {
                        Text(
                            text = "Save ~€${match.estimatedMonthlySavings.toInt()}/mo",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visa Track Note
            Text(
                text = "Visa Track: ${job.visaTrack}",
                style = MaterialTheme.typography.labelSmall,
                color = Slate400,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PipelineStatCard(
    count: Int,
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "$count",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Slate400,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun PillChip(icon: ImageVector, text: String) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = SkyBlueLight, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(5.dp))
            Text(text, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Medium)
        }
    }
}
