package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.remote.supabase.AuthState
import com.example.data.remote.supabase.SupabaseConfig
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate900
import com.example.ui.viewmodel.GlobalHireViewModel

@Composable
fun DevDiagnosticsDialog(
    viewModel: GlobalHireViewModel,
    onDismiss: () -> Unit
) {
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val cloudStatus by viewModel.cloudStatusMessage.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var customUrl by remember { mutableStateOf(SupabaseConfig.getSupabaseUrl(context)) }
    var customKey by remember { mutableStateOf(SupabaseConfig.getSupabaseAnonKey(context)) }

    val gateways = viewModel.repository.jobProviderRegistry.getGatewayInfoList()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = JobNexaAiBlue)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Developer & System Diagnostics", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Internal diagnostic panel isolated from the standard candidate interface.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Cloud Status
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Supabase Backend", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = JobNexaNavy)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (authState is AuthState.Authenticated) EmeraldContainer else Slate200
                            ) {
                                Text(
                                    text = if (authState is AuthState.Authenticated) "CONNECTED" else "LOCAL SANDBOX",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (authState is AuthState.Authenticated) EmeraldSuccess else Slate600,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when (val s = authState) {
                                is AuthState.Authenticated -> "User: ${s.user.email} (ID: ${s.user.id.take(8)}...)\nRow Level Security: Enforced\nStorage Bucket: candidate_documents (Private)"
                                else -> "Storage: Room SQLite Cache\nTenant ID: Local Sandbox User\nRLS Migration: Ready in supabase/migrations"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate900,
                            lineHeight = 16.sp
                        )

                        if (!cloudStatus.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(cloudStatus ?: "", style = MaterialTheme.typography.labelSmall, color = JobNexaAiBlue)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { viewModel.testCloudConnection() },
                            modifier = Modifier.fillMaxWidth().height(36.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ping Supabase REST Endpoints", fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Job Providers Gateway Status
                Text("Active Job Provider Integrations", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = JobNexaNavy)
                Spacer(modifier = Modifier.height(6.dp))

                gateways.forEach { gw ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate100),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(gw.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = JobNexaNavy)
                                Text(gw.statusText, color = EmeraldSuccess, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            }
                            Text("Region: ${gw.region}", style = MaterialTheme.typography.labelSmall, color = Slate600)
                            Text("Auth: ${gw.authType}", style = MaterialTheme.typography.labelSmall, color = Slate400)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Manual Credentials Override
                Text("Backend Secrets Override", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = JobNexaNavy)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = customUrl,
                    onValueChange = { customUrl = it },
                    label = { Text("SUPABASE_URL") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = customKey,
                    onValueChange = { customKey = it },
                    label = { Text("SUPABASE_ANON_KEY") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        viewModel.saveCustomCredentials(customUrl.trim(), customKey.trim())
                    },
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Save & Connect Supabase", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}
