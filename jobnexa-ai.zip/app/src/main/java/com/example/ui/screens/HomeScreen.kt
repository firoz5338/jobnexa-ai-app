package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Job
import com.example.ui.components.AntiFraudBanner
import com.example.ui.components.AntiFraudDialog
import com.example.ui.components.BlueCollarJobHelper
import com.example.ui.components.JobNexaSymbol
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaCyan
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.JobNexaNavyBorder
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate900
import com.example.ui.viewmodel.GlobalHireViewModel
import com.example.ui.viewmodel.JobRegions
import com.example.ui.viewmodel.RegionFilter
import com.example.ui.viewmodel.Screen

@Composable
fun HomeScreen(viewModel: GlobalHireViewModel) {
    val allJobs by viewModel.allJobs.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCountry by viewModel.selectedCountryFilter.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val selectedRegion by viewModel.selectedRegionFilter.collectAsStateWithLifecycle()

    var showAntiFraudDialog by remember { mutableStateOf(false) }

    // Machinery Categories
    val blueCollarCategories = listOf(
        "All Machinery",
        "🚜 Excavator & Bulldozer",
        "🏗️ Cranes & Rigging",
        "🚚 Haul Truck & Transport",
        "🔧 Plant Mechanics",
        "🛠️ Welding & Pipe",
        "⚙️ CNC & Tech"
    )

    // Filter jobs for display
    val displayJobs = allJobs.filter { job ->
        val matchesSearch = searchQuery.isBlank() ||
                job.title.contains(searchQuery, ignoreCase = true) ||
                job.company.contains(searchQuery, ignoreCase = true) ||
                job.country.contains(searchQuery, ignoreCase = true) ||
                job.requiredQualifications.contains(searchQuery, ignoreCase = true) ||
                job.requiredLicences.contains(searchQuery, ignoreCase = true)

        val matchesRegion = when (selectedRegion) {
            RegionFilter.ALL -> true
            RegionFilter.EUROPE -> JobRegions.isEurope(job.country)
            RegionFilter.GULF -> JobRegions.isGulf(job.country)
        }

        val matchesCountry = selectedCountry == "All Countries" ||
                job.country.equals(selectedCountry, ignoreCase = true) ||
                (selectedCountry == "United Arab Emirates" && job.country.contains("UAE", ignoreCase = true))

        val matchesCategory = when (selectedCategory) {
            "All", "All Machinery" -> true
            "🚜 Excavator & Bulldozer" -> job.title.contains("excavator", true) || job.title.contains("bulldozer", true) || job.title.contains("loader", true) || job.title.contains("earthmoving", true)
            "🏗️ Cranes & Rigging" -> job.title.contains("crane", true) || job.title.contains("rigging", true) || job.title.contains("rigger", true)
            "🚚 Haul Truck & Transport" -> job.title.contains("truck", true) || job.title.contains("mining", true) || job.title.contains("driver", true)
            "🔧 Plant Mechanics" -> job.title.contains("mechanic", true) || job.title.contains("hydraulic", true) || job.title.contains("fitter", true)
            "🛠️ Welding & Pipe" -> job.title.contains("welder", true) || job.title.contains("pipe", true)
            "⚙️ CNC & Tech" -> job.title.contains("cnc", true) || job.title.contains("mechatronics", true) || job.title.contains("technician", true)
            else -> true
        }

        matchesSearch && matchesRegion && matchesCountry && matchesCategory
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header with Logo & Brand
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    JobNexaSymbol(size = 40.dp, isDarkBg = true)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "JobNexa",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = JobNexaNavy
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "AI",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = JobNexaCyan
                            )
                        }
                        Text(
                            text = "Global Heavy Equipment & Technical Jobs",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate600,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Anti-fraud shield pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = EmeraldContainer,
                    border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .clickable { showAntiFraudDialog = true }
                        .testTag("header_anti_fraud_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Zero Fee Guard",
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Zero Fee",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                    }
                }
            }
        }

        // 4 Big-Button Quick Action Cards (Blue-collar friendly)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BigActionTile(
                        icon = "🔍",
                        title = "Find Jobs",
                        subtitle = "${allJobs.size} Verified Openings",
                        badge = "Direct",
                        containerColor = Color(0xFFF0F7FF),
                        borderColor = JobNexaAiBlue,
                        modifier = Modifier.weight(1f),
                        testTag = "home_tile_find_jobs",
                        onClick = { viewModel.navigateTo(Screen.SEARCH_JOBS) }
                    )

                    BigActionTile(
                        icon = "🚜",
                        title = "Profile & CV",
                        subtitle = "Operator Licences",
                        badge = "Ready",
                        containerColor = Color(0xFFF0FDF4),
                        borderColor = EmeraldSuccess,
                        modifier = Modifier.weight(1f),
                        testTag = "home_tile_profile",
                        onClick = { viewModel.navigateTo(Screen.PROFILE) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BigActionTile(
                        icon = "📋",
                        title = "My Applications",
                        subtitle = "Track Dossiers",
                        badge = "Real-Time",
                        containerColor = Color(0xFFFAF5FF),
                        borderColor = Color(0xFF9333EA),
                        modifier = Modifier.weight(1f),
                        testTag = "home_tile_applications",
                        onClick = { viewModel.navigateTo(Screen.MY_APPLICATIONS) }
                    )

                    BigActionTile(
                        icon = "🛡️",
                        title = "Anti-Fraud Guard",
                        subtitle = "100% Free Policy",
                        badge = "Safe",
                        containerColor = Color(0xFFFFF7ED),
                        borderColor = Color(0xFFF97316),
                        modifier = Modifier.weight(1f),
                        testTag = "home_tile_anti_fraud",
                        onClick = { showAntiFraudDialog = true }
                    )
                }
            }
        }

        // Prominent Anti-Fraud Banner
        item {
            AntiFraudBanner(onClick = { showAntiFraudDialog = true })
        }

        // Dual-Region Filtering Tabs (Europe vs. Gulf vs. All)
        item {
            Column {
                Text(
                    text = "Select Target Destination Region",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = JobNexaNavy
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Slate100)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Gulf Tab
                    val isGulf = selectedRegion == RegionFilter.GULF
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isGulf) JobNexaNavy else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clickable { viewModel.selectRegion(RegionFilter.GULF) }
                            .testTag("region_tab_gulf")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🇸🇦", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(
                                        text = "Gulf Jobs",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isGulf) Color.White else Slate900
                                    )
                                    Text(
                                        text = "0% Tax • Free Camp",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isGulf) JobNexaCyan else Slate600
                                    )
                                }
                            }
                        }
                    }

                    // Europe Tab
                    val isEurope = selectedRegion == RegionFilter.EUROPE
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isEurope) JobNexaNavy else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clickable { viewModel.selectRegion(RegionFilter.EUROPE) }
                            .testTag("region_tab_europe")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🇪🇺", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(
                                        text = "Europe Jobs",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isEurope) Color.White else Slate900
                                    )
                                    Text(
                                        text = "Blue Card / Visa",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isEurope) JobNexaCyan else Slate600
                                    )
                                }
                            }
                        }
                    }

                    // All Tab
                    val isAll = selectedRegion == RegionFilter.ALL
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isAll) JobNexaNavy else Color.Transparent,
                        modifier = Modifier
                            .weight(0.7f)
                            .height(48.dp)
                            .clickable { viewModel.selectRegion(RegionFilter.ALL) }
                            .testTag("region_tab_all")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "🌐 All",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isAll) Color.White else Slate900
                            )
                        }
                    }
                }
            }
        }

        // Search Input Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_input"),
                placeholder = {
                    Text(
                        text = "Search: Excavator, Crane, Bulldozer, Welder...",
                        color = Slate400,
                        fontSize = 14.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = JobNexaAiBlue
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Slate100,
                    focusedBorderColor = JobNexaAiBlue,
                    unfocusedBorderColor = Slate200,
                    focusedTextColor = Slate900,
                    unfocusedTextColor = Slate900
                )
            )
        }

        // Machinery Category Chips
        item {
            Column {
                Text(
                    text = "Equipment & Trade Specialties",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = JobNexaNavy
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(blueCollarCategories) { cat ->
                        val isSelected = selectedCategory == cat || (selectedCategory == "All" && cat == "All Machinery")
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) JobNexaNavy else Slate100,
                            border = BorderStroke(1.dp, if (isSelected) JobNexaNavy else Slate200),
                            modifier = Modifier
                                .clickable {
                                    viewModel.selectedCategoryFilter.value = if (cat == "All Machinery") "All" else cat
                                }
                                .testTag("cat_chip_${cat.take(5)}")
                        ) {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Slate900,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Available Vacancies
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = when (selectedRegion) {
                            RegionFilter.GULF -> "🇸🇦 Gulf Direct Vacancies"
                            RegionFilter.EUROPE -> "🇪🇺 Europe Direct Vacancies"
                            RegionFilter.ALL -> "🌐 Global Verified Vacancies"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = JobNexaNavy
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Slate100
                ) {
                    Text(
                        text = "${displayJobs.size} available",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Slate600,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Job Cards with High Contrast & Big Buttons
        items(displayJobs) { job ->
            HomeJobCard(
                job = job,
                onViewClick = {
                    viewModel.openJobDetail(job)
                }
            )
        }

        // Search More Button at Bottom
        item {
            OutlinedButton(
                onClick = { viewModel.navigateTo(Screen.SEARCH_JOBS) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("explore_more_jobs_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.5.dp, JobNexaNavy)
            ) {
                Text(
                    text = "Open Advanced Search & Filters (${allJobs.size} Jobs)",
                    fontWeight = FontWeight.Bold,
                    color = JobNexaNavy,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = JobNexaNavy, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showAntiFraudDialog) {
        AntiFraudDialog(onDismiss = { showAntiFraudDialog = false })
    }
}

@Composable
private fun BigActionTile(
    icon: String,
    title: String,
    subtitle: String,
    badge: String,
    containerColor: Color,
    borderColor: Color,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.5f)),
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = icon, fontSize = 24.sp)
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = borderColor
                ) {
                    Text(
                        text = badge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = JobNexaNavy
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = Slate600
                )
            }
        }
    }
}

@Composable
fun HomeJobCard(
    job: Job,
    onViewClick: () -> Unit
) {
    val breakdown = remember(job) { BlueCollarJobHelper.calculateFinancialBreakdown(job) }
    val machineryIcon = remember(job.title) { BlueCollarJobHelper.getRoleMachineryIcon(job.title) }
    val countryFlag = remember(job.country) { BlueCollarJobHelper.getCountryFlag(job.country) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Slate200),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("job_card_${job.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Machinery Icon + Company + Direct Apply Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Slate100,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = machineryIcon, fontSize = 20.sp)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = job.company,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate900
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Verified Employer",
                                tint = JobNexaAiBlue,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "Direct Employer • Zero Fee",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Region / Country Flag pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate100
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = countryFlag, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = job.city,
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate900,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Job Title (Big, clear, readable)
            Text(
                text = job.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = JobNexaNavy,
                fontSize = 17.sp,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Transparent Financial Box: Net Savings Estimator
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (breakdown.isGulf) Color(0xFFF0FDF4) else Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, if (breakdown.isGulf) EmeraldSuccess.copy(alpha = 0.5f) else Slate200),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Gross: ${job.currency} ${job.grossSalaryMonthly.toInt()}/mo",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = breakdown.savingsHighlight,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldSuccess
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Visa Track & Food/Housing Info Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SkyBlueContainer,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = breakdown.visaTrackLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = JobNexaNavy,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        maxLines = 1
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (breakdown.isHousingFree) EmeraldContainer else Slate100
                ) {
                    Text(
                        text = if (breakdown.isHousingFree) "Free Food & Camp" else "Visa Sponsored",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (breakdown.isHousingFree) EmeraldSuccess else Slate600,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Big Action Button (>= 50dp high, accessible, high contrast)
            Button(
                onClick = onViewClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("view_job_button_${job.id}")
            ) {
                Text(
                    text = "View & Direct Apply",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = JobNexaCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
