package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Job
import com.example.data.model.JobMatch
import com.example.data.remote.supabase.AuthState
import com.example.domain.TranslationLanguageManager
import com.example.domain.TranslationResult
import com.example.ui.components.BlueCollarJobHelper
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaCyan
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate900
import com.example.ui.viewmodel.GlobalHireViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun JobDetailBottomSheet(
    viewModel: GlobalHireViewModel,
    job: Job,
    match: JobMatch?,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val targetLang by viewModel.targetTranslationLanguage.collectAsStateWithLifecycle()
    val isTranslating by viewModel.isTranslatingJobDescription.collectAsStateWithLifecycle()
    val translationResult by viewModel.activeJobTranslation.collectAsStateWithLifecycle()

    val isAuthenticated = authState is AuthState.Authenticated || authState is AuthState.SandboxDemo

    var showApplyConfirmDialog by remember { mutableStateOf(false) }
    var showLanguageOverrideDialog by remember { mutableStateOf(false) }
    var showOriginalText by remember { mutableStateOf(false) }
    var customLanguageInput by remember { mutableStateOf("") }

    val financial = remember(job) { BlueCollarJobHelper.calculateFinancialBreakdown(job) }
    val machineryIcon = remember(job.title) { BlueCollarJobHelper.getRoleMachineryIcon(job.title) }
    val countryFlag = remember(job.country) { BlueCollarJobHelper.getCountryFlag(job.country) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        modifier = Modifier.testTag("job_detail_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header: Employer + Verified Pill + Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Slate100,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = machineryIcon, fontSize = 20.sp)
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = job.company,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Slate900
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.Verified, contentDescription = null, tint = JobNexaAiBlue, modifier = Modifier.size(14.dp))
                        }
                        Text(
                            text = "Direct Employer • Official Portal",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_job_detail_button")) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate400)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Job Title
            Text(
                text = job.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = JobNexaNavy,
                fontSize = 20.sp,
                lineHeight = 26.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Location & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = countryFlag, fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${job.city}, ${job.country}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = JobNexaNavy
                    )
                }

                Text(
                    text = "• ${job.employmentType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Transparent Financial & Net Savings Estimator Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (financial.isGulf) Color(0xFFF0FDF4) else Color(0xFFF8FAFC)
                ),
                border = BorderStroke(1.5.dp, if (financial.isGulf) EmeraldSuccess.copy(alpha = 0.5f) else Slate200),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Transparent Salary & Net Savings Breakdown",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = JobNexaNavy
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (financial.isGulf) EmeraldSuccess else JobNexaAiBlue
                        ) {
                            Text(
                                text = if (financial.isGulf) "0% TAX GULF" else "EU STANDARD",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Gross Monthly", style = MaterialTheme.typography.labelSmall, color = Slate600)
                            Text(
                                text = "${job.currency} ${job.grossSalaryMonthly.toInt()}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate900
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Income Tax", style = MaterialTheme.typography.labelSmall, color = Slate600)
                            Text(
                                text = if (financial.taxRatePercent == 0) "0% (Free)" else "${financial.taxRatePercent}%",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (financial.taxRatePercent == 0) EmeraldSuccess else Slate900
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Est. Net Monthly Savings", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                            Text(
                                text = "+${job.currency} ${financial.estimatedNetMonthlySavings.toInt()}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldSuccess
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = Slate200)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Housing & Camp info
                    Text(
                        text = "🏠 Food & Housing: ${financial.foodHousingStatus}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate900,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Visa track note
                    Text(
                        text = "🛂 Visa Pathway: ${financial.visaTrackLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = JobNexaNavy,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Prominent Anti-Scam Zero-Fee Warning Box
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFEF2F2),
                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Security Alert",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ANTI-FRAUD GUARD: ZERO RECRUITMENT FEES",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "All visa, medical screening, and flight fees are 100% paid by ${job.company}. Never pay any agency, recruiter, or middleman for application or interview processing.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF7F1D1D),
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AI Job Translation Control Bar
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Slate100,
                border = BorderStroke(1.dp, Slate200),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("job_translation_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Target language pill / override button
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { showLanguageOverrideDialog = true }
                                .padding(vertical = 4.dp, horizontal = 6.dp)
                                .testTag("target_language_selector_button")
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = JobNexaAiBlue, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Translate to: $targetLang",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = JobNexaNavy
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Change target language", tint = Slate600, modifier = Modifier.size(18.dp))
                        }

                        // Translate or View Original / View Translation Button
                        if (translationResult is TranslationResult.Success) {
                            TextButton(
                                onClick = { showOriginalText = !showOriginalText },
                                modifier = Modifier.testTag("view_original_toggle_button")
                            ) {
                                Text(
                                    text = if (showOriginalText) "View Translation" else "View Original",
                                    fontWeight = FontWeight.Bold,
                                    color = JobNexaAiBlue,
                                    fontSize = 12.sp
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    showOriginalText = false
                                    viewModel.translateJobDescription(job, targetLang)
                                },
                                enabled = !isTranslating,
                                colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("translate_job_button")
                            ) {
                                if (isTranslating) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(14.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Translating...", fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Translate", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Translation Status Banner
                    if (translationResult is TranslationResult.Success) {
                        val success = translationResult as TranslationResult.Success
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SkyBlueContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = JobNexaAiBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (showOriginalText) {
                                        "Viewing Employer's Original English Text"
                                    } else {
                                        "AI-Translated to ${success.targetLanguage} • Original English Preserved"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = JobNexaNavy
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Body Description
            val currentDescriptionText = when {
                translationResult is TranslationResult.Success && !showOriginalText -> {
                    (translationResult as TranslationResult.Success).translatedText
                }
                else -> job.description
            }

            Text(
                text = "Job Description & Responsibilities",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = JobNexaNavy
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = currentDescriptionText,
                style = MaterialTheme.typography.bodyMedium,
                color = Slate900,
                lineHeight = 22.sp,
                modifier = Modifier.testTag("job_description_text")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Requirements Section
            DetailRequirementItem(label = "Required Qualifications", value = job.requiredQualifications)
            DetailRequirementItem(label = "Licences & Safety Credentials", value = job.requiredLicences)
            DetailRequirementItem(label = "Required Languages", value = job.requiredLanguages)
            DetailRequirementItem(label = "Minimum Experience", value = "${job.minYearsExperience} years verified experience")

            if (job.officialVisaSource.isNotBlank()) {
                DetailRequirementItem(label = "Official Visa & Labor Authority", value = "${job.officialVisaSource} (${job.visaTrack})")
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Big Button: Direct Employer Apply
            Button(
                onClick = {
                    if (!isAuthenticated) {
                        viewModel.pendingJobToApply.value = job
                        viewModel.userNotification.value = "Please sign in or create an account to proceed with direct employer application."
                        viewModel.openSignIn()
                    } else {
                        showApplyConfirmDialog = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("apply_now_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, tint = JobNexaCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Apply on Official Employer Site",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
        }
    }

    // Language Override Dialog
    if (showLanguageOverrideDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageOverrideDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = JobNexaAiBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Select Translation Language")
                }
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "Detected language: $targetLang\nSelect a target language to translate this job description:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Popular Languages:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = JobNexaNavy
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TranslationLanguageManager.POPULAR_LANGUAGES.forEach { lang ->
                            val isSelected = targetLang.equals(lang, ignoreCase = true)
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) JobNexaNavy else Slate100,
                                border = if (isSelected) null else BorderStroke(1.dp, Slate200),
                                modifier = Modifier
                                    .clickable {
                                        viewModel.setTargetTranslationLanguage(lang)
                                        showLanguageOverrideDialog = false
                                        viewModel.translateJobDescription(job, lang)
                                    }
                                    .testTag("select_target_lang_$lang")
                            ) {
                                Text(
                                    text = lang,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) Color.White else Slate900,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Or type another language:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = JobNexaNavy
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = customLanguageInput,
                        onValueChange = { customLanguageInput = it },
                        placeholder = { Text("e.g. Hindi, Urdu, Arabic, Tagalog, Polish...") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_language_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val chosen = customLanguageInput.trim()
                        if (chosen.isNotBlank()) {
                            viewModel.setTargetTranslationLanguage(chosen)
                            viewModel.translateJobDescription(job, chosen)
                        }
                        showLanguageOverrideDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                    modifier = Modifier.testTag("confirm_custom_language_button")
                ) {
                    Text("Apply Language")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLanguageOverrideDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Direct Application Confirmation Dialog
    if (showApplyConfirmDialog) {
        val isExternal = job.applicationMethod == "EXTERNAL_PORTAL" || job.applicationMethod == "PORTAL_GUIDED"

        AlertDialog(
            onDismissRequest = { showApplyConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = JobNexaAiBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isExternal) "Direct Employer Portal" else "Direct Dossier Submission")
                }
            },
            text = {
                Column {
                    Text(
                        text = if (isExternal) {
                            "You are applying directly with ${job.company} for '${job.title}'.\n\nJobNexa AI will open the official employer application portal without any middleman agencies. Your application progress will be tracked in 'My Applications'."
                        } else {
                            "You are submitting your verified candidate profile and CV directly to ${job.company}.\n\nZero fees will ever be charged."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = Slate900,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showApplyConfirmDialog = false
                        viewModel.applyToJob(context, job)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JobNexaNavy),
                    modifier = Modifier.testTag("confirm_apply_submission_button")
                ) {
                    Text(if (isExternal) "Open Employer Website" else "Confirm & Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApplyConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun DetailRequirementItem(label: String, value: String) {
    if (value.isNotBlank()) {
        Column(modifier = Modifier.padding(vertical = 5.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate600)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.bodySmall, color = Slate900)
        }
    }
}
