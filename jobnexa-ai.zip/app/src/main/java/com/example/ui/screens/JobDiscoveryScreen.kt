package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.EmptyStateView
import com.example.ui.components.getCountryFlagEmoji
import com.example.ui.theme.Slate400
import com.example.ui.viewmodel.GlobalHireViewModel

@Composable
fun JobDiscoveryScreen(viewModel: GlobalHireViewModel) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCountry by viewModel.selectedCountryFilter.collectAsStateWithLifecycle()
    val selectedSponsorship by viewModel.selectedSponsorshipFilter.collectAsStateWithLifecycle()
    val filteredJobs by viewModel.filteredJobs.collectAsStateWithLifecycle()

    val countries = listOf(
        "All Countries",
        "Germany",
        "Netherlands",
        "Poland",
        "Saudi Arabia",
        "United Arab Emirates",
        "Sweden",
        "Austria",
        "Qatar"
    )

    val sponsorships = listOf("All", "Verified Sponsor", "Sponsorship Available")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.searchQuery.value = it },
            placeholder = { Text("Search by title, equipment, or skill (e.g. CNC, PLC)...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate400) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_jobs_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Country Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(countries) { country ->
                val isSelected = selectedCountry.equals(country, ignoreCase = true)
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectedCountryFilter.value = country },
                    label = {
                        val flag = if (country == "All Countries") "🌍" else getCountryFlagEmoji(country)
                        Text("$flag $country")
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Sponsorship Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(sponsorships) { sp ->
                val isSelected = selectedSponsorship == sp
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectedSponsorshipFilter.value = sp },
                    label = { Text(sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Results Count Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${filteredJobs.size} Verified Vacancies",
                style = MaterialTheme.typography.labelMedium,
                color = Slate400,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Ranked by AI Match",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Job Cards List
        if (filteredJobs.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.Work,
                title = "No Matching Jobs Found",
                message = "Try clearing your search query or adjusting the country and sponsorship filters.",
                actionText = "Reset Filters",
                onAction = {
                    viewModel.searchQuery.value = ""
                    viewModel.selectedCountryFilter.value = "All Countries"
                    viewModel.selectedSponsorshipFilter.value = "All"
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredJobs) { (job, match) ->
                    JobCardItem(
                        job = job,
                        match = match,
                        onClick = { viewModel.openJobDetail(job) },
                        onToggleSave = { viewModel.toggleSaveJob(job.id, match?.isSaved == true) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
