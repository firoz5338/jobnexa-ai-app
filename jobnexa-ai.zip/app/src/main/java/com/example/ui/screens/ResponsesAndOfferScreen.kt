package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EmployerMessage
import com.example.data.model.OfferReview
import com.example.ui.components.SectionHeader
import com.example.ui.components.getCountryFlagEmoji
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.CoralContainer
import com.example.ui.theme.CoralError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NavyDark
import com.example.ui.theme.SkyBlueContainer
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.viewmodel.GlobalHireViewModel

@Composable
fun ResponsesAndOfferScreen(viewModel: GlobalHireViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    val messages by viewModel.allMessages.collectAsStateWithLifecycle()
    val offerReviews by viewModel.allOfferReviews.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Employer Inbox (${messages.size})")
                    }
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Offer Verification")
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedTab == 0) {
            EmployerInboxTab(messages = messages, onMarkRead = { viewModel.markMessageRead(it) })
        } else {
            OfferVerificationTab(
                reviews = offerReviews,
                onScanOffer = { comp, role, country, sal, curr, contract, text, file ->
                    viewModel.scanOfferDocument(comp, role, country, sal, curr, contract, text, file)
                }
            )
        }
    }
}

@Composable
private fun EmployerInboxTab(
    messages: List<EmployerMessage>,
    onMarkRead: (String) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Verified Employer Responses",
                subtitle = "Automated matching of replies to your active applications"
            )
        }

        items(messages) { msg ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (msg.isRead) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = if (!msg.isRead) 1.5.dp else 0.dp,
                        color = if (!msg.isRead) SkyBluePrimary else Color.Transparent,
                        shape = RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = if (msg.category == "INTERVIEW_INVITATION") EmeraldContainer else SkyBlueContainer,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (msg.category == "INTERVIEW_INVITATION") Icons.Default.VideoCall else Icons.Default.Email,
                                        contentDescription = null,
                                        tint = if (msg.category == "INTERVIEW_INVITATION") EmeraldSuccess else SkyBluePrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(msg.company, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(msg.senderName, style = MaterialTheme.typography.labelSmall, color = Slate400)
                            }
                        }
                        Text(msg.receivedDate, style = MaterialTheme.typography.labelSmall, color = Slate400)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = msg.subject,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = msg.bodySnippet,
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate400,
                        lineHeight = 18.sp
                    )

                    if (msg.interviewDate != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = EmeraldContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Interview Scheduled: ${msg.interviewDate}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess
                                    )
                                }
                                if (msg.interviewFormat != null) {
                                    Text(
                                        text = "Format: ${msg.interviewFormat}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NavyDark
                                    )
                                }
                                if (msg.interviewLink != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(msg.interviewLink))
                                            context.startActivity(intent)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                                    ) {
                                        Text("Join Meeting")
                                    }
                                }
                            }
                        }
                    }

                    if (!msg.isRead) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            OutlinedButton(onClick = { onMarkRead(msg.id) }) {
                                Text("Mark as Read")
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun OfferVerificationTab(
    reviews: List<OfferReview>,
    onScanOffer: (String, String, String, Double, String, String, String, String) -> Unit
) {
    var companyName by remember { mutableStateOf("Rotterdam World Gateway (RWG)") }
    var roleTitle by remember { mutableStateOf("Logistics Fleet & Heavy Equipment Supervisor") }
    var country by remember { mutableStateOf("Netherlands") }
    var salaryText by remember { mutableStateOf("4500") }
    var contractType by remember { mutableStateOf("Permanent Full-Time") }
    var documentText by remember { mutableStateOf("Formal employment offer for Alex Mercer. Monthly gross salary €4,500 with standard 38-hour week. Employer RWG sponsors IND work permit fees and 30% tax facility.") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Job Offer Scanner & Fraud Guard",
                subtitle = "Independent legal and regulatory cross-reference of international offer letters"
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Scan New Offer Document",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Quick load sample to test fraud detection:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                companyName = "Rotterdam World Gateway (RWG)"
                                roleTitle = "Logistics Fleet & Equipment Supervisor"
                                country = "Netherlands"
                                salaryText = "4500"
                                contractType = "Permanent"
                                documentText = "Formal employment offer from RWG Maasvlakte Rotterdam. Gross €4,500/mo. Full IND sponsorship covered by employer. No candidate fees."
                            },
                            modifier = Modifier.testTag("load_genuine_offer_button")
                        ) {
                            Text("Genuine Dutch Offer", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                companyName = "Dubai Gulf Construction Ltd"
                                roleTitle = "Excavator Fleet General Manager"
                                country = "United Arab Emirates"
                                salaryText = "24000"
                                contractType = "2-Year Contract"
                                documentText = "CONGRATULATIONS! You have been selected. Send processing fee of $850 USD via Western Union / Wire Transfer to our official agent for urgent MoHRE visa stamping. Email: recruiter@gmail.com."
                            },
                            modifier = Modifier.testTag("load_scam_offer_button")
                        ) {
                            Text("Advance-Fee Scam Sample", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = companyName,
                        onValueChange = { companyName = it },
                        label = { Text("Company Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = roleTitle,
                            onValueChange = { roleTitle = it },
                            label = { Text("Role") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = country,
                            onValueChange = { country = it },
                            label = { Text("Country") },
                            modifier = Modifier.weight(0.8f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = salaryText,
                        onValueChange = { salaryText = it },
                        label = { Text("Monthly Gross Salary (€)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = documentText,
                        onValueChange = { documentText = it },
                        label = { Text("Offer Document Text / Terms") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val sal = salaryText.toDoubleOrNull() ?: 4500.0
                            onScanOffer(
                                companyName,
                                roleTitle,
                                country,
                                sal,
                                "EUR",
                                contractType,
                                documentText,
                                "Offer_Review_${System.currentTimeMillis() % 1000}.pdf"
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("scan_offer_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyze Contract & Verify Legitimacy", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Previous Scans & Reviews
        item {
            SectionHeader(
                title = "Verification History",
                subtitle = "Past contracts analyzed against commercial registries and anti-fraud rules"
            )
        }

        items(reviews) { rev ->
            val isAuthentic = rev.verificationOutcome == "AUTHENTIC_VERIFIED"
            val (badgeBg, badgeFg, icon) = if (isAuthentic) {
                Triple(EmeraldContainer, EmeraldSuccess, Icons.Default.Verified)
            } else {
                Triple(CoralContainer, CoralError, Icons.Default.Warning)
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(getCountryFlagEmoji(rev.country), fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(rev.companyName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${rev.roleTitle} • ${rev.country}", style = MaterialTheme.typography.bodySmall, color = Slate400)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = badgeBg
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = null, tint = badgeFg, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isAuthentic) "AUTHENTIC (Risk ${rev.riskScore}/100)" else "HIGH RISK (${rev.riskScore}/100)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = badgeFg
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Official Registry Check: ${rev.officialRegistryCheck}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isAuthentic) EmeraldContainer.copy(alpha = 0.5f) else CoralContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = rev.feePolicyNotice,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isAuthentic) EmeraldSuccess else CoralError,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Recommended Action: ${rev.recommendedActions}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
