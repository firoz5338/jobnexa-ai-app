package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Job
import com.example.ui.components.AntiFraudDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JobNexaAiBlue
import com.example.ui.theme.JobNexaCyan
import com.example.ui.theme.JobNexaNavy
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate900
import com.example.ui.viewmodel.GlobalHireViewModel
import com.example.ui.viewmodel.JobRegions
import com.example.ui.viewmodel.RegionFilter

@Composable
fun SearchJobsScreen(viewModel: GlobalHireViewModel) {
    val allJobs by viewModel.allJobs.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCountry by viewModel.selectedCountryFilter.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val selectedRegion by viewModel.selectedRegionFilter.collectAsStateWithLifecycle()
    val visaSponsorshipOnly by viewModel.visaSponsorshipOnly.collectAsStateWithLifecycle()

    var showCountryDropdown by remember { mutableStateOf(false) }
    var showAntiFraudDialog by remember { mutableStateOf(false) }

    val countries = when (selectedRegion) {
        RegionFilter.GULF -> listOf(
            "All Countries",
            "Saudi Arabia",
            "United Arab Emirates",
            "Qatar"
        )
        RegionFilter.EUROPE -> listOf(
            "All Countries",
            "Germany",
            "Netherlands",
            "Poland",
            "Sweden",
            "Austria"
        )
        RegionFilter.ALL -> listOf(
            "All Countries",
            "Saudi Arabia",
            "United Arab Emirates",
            "Qatar",
            "Germany",
            "Netherlands",
            "Poland",
            "Sweden",
            "Austria"
        )
    }

    val blueCollarCategories = listOf(
        "All Machinery",
        "🚜 Excavator & Bulldozer",
        "🏗️ Cranes & Rigging",
        "🚚 Haul Truck & Mining",
        "🔧 Plant Mechanics",
        "🛠️ Welding & Pipe",
        "⚙️ CNC & Tech"
    )

    val filteredJobs = allJobs.filter { job ->
        val matchesSearch = searchQuery.isBlank() ||
                job.title.contains(searchQuery, ignoreCase = true) ||
                job.company.contains(searchQuery, ignoreCase = true) ||
                job.description.contains(searchQuery, ignoreCase = true) ||
                job.requiredQualifications.contains(searchQuery, ignoreCase = true) ||
                job.requiredLicences.contains(searchQuery, ignoreCase = true)

        val matchesRegion = when (selectedRegion) {
            RegionFilter.ALL -> true
            RegionFilter.EUROPE -> JobRegions.isEurope(job.country)
            RegionFilter.GULF -> JobRegions.isGulf(job.country)
        }

        val matchesCountry = selectedCountry == "All Countries" ||
                job.country.equals(selectedCountry, ignoreCase = true) ||
                (selectedCountry == "United Arab Emirates" && job.country.contains("UAE", ignoreCase = true))

        val matchesCategory = when (selectedCategory) {
            "All", "All Machinery" -> true
            "🚜 Excavator & Bulldozer" -> job.title.contains("excavator", true) || job.title.contains("bulldozer", true) || job.title.contains("loader", true) || job.title.contains("earthmoving", true)
            "🏗️ Cranes & Rigging" -> job.title.contains("crane", true) || job.title.contains("rigging", true) || job.title.contains("rigger", true)
            "🚚 Haul Truck & Mining" -> job.title.contains("truck", true) || job.title.contains("mining", true) || job.title.contains("driver", true)
            "🔧 Plant Mechanics" -> job.title.contains("mechanic", true) || job.title.contains("hydraulic", true) || job.title.contains("fitter", true)
            "🛠️ Welding & Pipe" -> job.title.contains("welder", true) || job.title.contains("pipe", true)
            "⚙️ CNC & Tech" -> job.title.contains("cnc", true) || job.title.contains("mechatronics", true) || job.title.contains("technician", true)
            else -> true
        }

        val matchesVisa = !visaSponsorshipOnly || job.sponsorshipStatus.contains("Sponsor", ignoreCase = true)

        matchesSearch && matchesRegion && matchesCountry && matchesCategory && matchesVisa
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Find Heavy Equipment Jobs",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = JobNexaNavy
                    )
                    Text(
                        text = "Verified Direct Openings in Europe & Gulf",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = EmeraldContainer,
                    modifier = Modifier
                        .clickable { showAntiFraudDialog = true }
                        .testTag("search_anti_fraud_shield")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Zero Fee", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                    }
                }
            }
        }

        // Dual-Region Top Toggle
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Slate100)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                // Gulf Tab
                val isGulf = selectedRegion == RegionFilter.GULF
                Surface(
                    shape = RoundedCornerShape(9.dp),
                    color = if (isGulf) JobNexaNavy else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clickable { viewModel.selectRegion(RegionFilter.GULF) }
                        .testTag("search_region_tab_gulf")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "🇸🇦 Gulf Jobs (0% Tax)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isGulf) Color.White else Slate900
                        )
                    }
                }

                // Europe Tab
                val isEurope = selectedRegion == RegionFilter.EUROPE
                Surface(
                    shape = RoundedCornerShape(9.dp),
                    color = if (isEurope) JobNexaNavy else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clickable { viewModel.selectRegion(RegionFilter.EUROPE) }
                        .testTag("search_region_tab_europe")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "🇪🇺 Europe (Work Visa)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isEurope) Color.White else Slate900
                        )
                    }
                }

                // All Tab
                val isAll = selectedRegion == RegionFilter.ALL
                Surface(
                    shape = RoundedCornerShape(9.dp),
                    color = if (isAll) JobNexaNavy else Color.Transparent,
                    modifier = Modifier
                        .weight(0.6f)
                        .height(44.dp)
                        .clickable { viewModel.selectRegion(RegionFilter.ALL) }
                        .testTag("search_region_tab_all")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "🌐 All",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isAll) Color.White else Slate900
                        )
                    }
                }
            }
        }

        // Search Input
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_jobs_input"),
                placeholder = {
                    Text(
                        text = "Keywords: Bulldozer, CAT D11, Crane, Liebherr...",
                        color = Slate400,
                        fontSize = 14.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = JobNexaAiBlue
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Slate400)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Slate100,
                    focusedBorderColor = JobNexaAiBlue,
                    unfocusedBorderColor = Slate200,
                    focusedTextColor = Slate900,
                    unfocusedTextColor = Slate900
                )
            )
        }

        // Category Filter Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(blueCollarCategories) { cat ->
                    val isSelected = selectedCategory == cat || (selectedCategory == "All" && cat == "All Machinery")
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isSelected) JobNexaNavy else Slate100,
                        border = BorderStroke(1.dp, if (isSelected) JobNexaNavy else Slate200),
                        modifier = Modifier
                            .clickable {
                                viewModel.selectedCategoryFilter.value = if (cat == "All Machinery") "All" else cat
                            }
                            .testTag("search_cat_${cat.take(5)}")
                    ) {
                        Text(
                            text = cat,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Slate900,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // Country Dropdown Filter & Visa Toggle Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Country Filter Button
                Box {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Slate100,
                        border = BorderStroke(1.dp, Slate200),
                        modifier = Modifier
                            .clickable { showCountryDropdown = true }
                            .testTag("country_filter_dropdown_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.FilterList, contentDescription = null, tint = Slate600, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedCountry,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Slate900
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showCountryDropdown,
                        onDismissRequest = { showCountryDropdown = false }
                    ) {
                        countries.forEach { country ->
                            DropdownMenuItem(
                                text = { Text(country) },
                                onClick = {
                                    viewModel.selectedCountryFilter.value = country
                                    showCountryDropdown = false
                                }
                            )
                        }
                    }
                }

                // Visa Sponsorship Toggle
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Visa Included",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = Slate900
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Switch(
                        checked = visaSponsorshipOnly,
                        onCheckedChange = { viewModel.visaSponsorshipOnly.value = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = JobNexaNavy
                        ),
                        modifier = Modifier.testTag("visa_sponsorship_switch")
                    )
                }
            }
        }

        // Results Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Matching Vacancies (${filteredJobs.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = JobNexaNavy
                )
                if (searchQuery.isNotBlank() || selectedCountry != "All Countries" || selectedCategory != "All") {
                    Text(
                        text = "Reset Filters",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = JobNexaAiBlue,
                        modifier = Modifier
                            .clickable {
                                viewModel.searchQuery.value = ""
                                viewModel.selectedCountryFilter.value = "All Countries"
                                viewModel.selectedCategoryFilter.value = "All"
                                viewModel.visaSponsorshipOnly.value = false
                            }
                            .padding(4.dp)
                            .testTag("reset_filters_button")
                    )
                }
            }
        }

        // Empty State or List of HomeJobCards
        if (filteredJobs.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.Search,
                    title = "No vacancies found",
                    message = "Try clearing your search terms or switching between Europe and Gulf region tabs.",
                    actionText = "Show All Machinery Jobs",
                    onAction = {
                        viewModel.searchQuery.value = ""
                        viewModel.selectedCountryFilter.value = "All Countries"
                        viewModel.selectedCategoryFilter.value = "All"
                        viewModel.selectedRegionFilter.value = RegionFilter.ALL
                        viewModel.visaSponsorshipOnly.value = false
                    }
                )
            }
        } else {
            items(filteredJobs) { job ->
                HomeJobCard(
                    job = job,
                    onViewClick = {
                        viewModel.openJobDetail(job)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showAntiFraudDialog) {
        AntiFraudDialog(onDismiss = { showAntiFraudDialog = false })
    }
}
