package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JobNexa AI Brand Palette — Your AI Agent for Global Jobs
val JobNexaNavy = Color(0xFF0C1729) // Deep Navy background
val JobNexaCyan = Color(0xFF54D9F5) // Electric Cyan accent / highlight
val JobNexaAiBlue = Color(0xFF4C91FF) // AI Blue primary
val JobNexaNavySurface = Color(0xFF13233D) // Card & panel surface
val JobNexaNavyBorder = Color(0xFF1E355B) // Border outline

val NavyDeep = Color(0xFF0C1729)
val NavyDark = Color(0xFF101D33)
val NavySurface = Color(0xFF13233D)
val NavyLight = Color(0xFF1C2E4C)

val SkyBluePrimary = Color(0xFF4C91FF) // JobNexa AI Blue
val SkyBlueLight = Color(0xFF54D9F5) // JobNexa Electric Cyan
val SkyBlueContainer = Color(0xFFDCEBFF)
val SkyBlueDarkContainer = Color(0xFF0D3366)

val AmberAccent = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)

val CoralError = Color(0xFFEF4444)
val CoralContainer = Color(0xFFFEE2E2)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate400 = Color(0xFF94A3B8)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
