package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = JobNexaCyan,
    onPrimary = JobNexaNavy,
    primaryContainer = SkyBlueDarkContainer,
    onPrimaryContainer = SkyBlueContainer,
    secondary = JobNexaAiBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1E3A5F),
    onSecondaryContainer = SkyBlueContainer,
    tertiary = AmberAccent,
    onTertiary = JobNexaNavy,
    background = JobNexaNavy,
    onBackground = Color(0xFFF1F5F9),
    surface = NavyDark,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = JobNexaNavySurface,
    onSurfaceVariant = Slate400,
    outline = JobNexaNavyBorder
)

private val LightColorScheme = lightColorScheme(
    primary = JobNexaAiBlue,
    onPrimary = Color.White,
    primaryContainer = SkyBlueContainer,
    onPrimaryContainer = SkyBlueDarkContainer,
    secondary = JobNexaCyan,
    onSecondary = JobNexaNavy,
    secondaryContainer = Color(0xFFE0F7FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = AmberAccent,
    onTertiary = Color.White,
    background = Slate50,
    onBackground = Slate900,
    surface = Color.White,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate600,
    outline = Slate200
)

@Composable
fun JobNexaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use intentional JobNexa AI brand colors (#0C1729, #54D9F5, #4C91FF)
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward-compatible alias for existing references
@Composable
fun GlobalHireTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    JobNexaTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
