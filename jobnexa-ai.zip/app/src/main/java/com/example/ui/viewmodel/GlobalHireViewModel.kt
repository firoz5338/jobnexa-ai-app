package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.Application as JobApplication
import com.example.data.model.AuditLog
import com.example.data.model.CandidateProfile
import com.example.data.model.EmployerMessage
import com.example.data.model.Job
import com.example.data.model.JobMatch
import com.example.data.model.JobSource
import com.example.data.model.OfferReview
import com.example.data.remote.supabase.AuthResult
import com.example.data.remote.supabase.AuthState
import com.example.data.remote.supabase.StorageUploadResult
import com.example.data.remote.supabase.SupabaseConfig
import com.example.data.repository.GlobalHireRepository
import com.example.data.seed.SeedData
import com.example.domain.CvParserAgent
import com.example.domain.ExtractedCvData
import com.example.domain.OfferVerificationAgent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.domain.AiCvParserService
import com.example.domain.AiTranslationService
import com.example.domain.CvParseResult
import com.example.domain.TranslationLanguageManager
import com.example.domain.TranslationResult
import com.example.ui.i18n.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    SEARCH_JOBS,
    MY_APPLICATIONS,
    PROFILE,
    DEV_DIAGNOSTICS,
    // Aliases for compatibility
    DASHBOARD,
    JOB_DISCOVERY,
    APPLICATIONS_PIPELINE,
    RESPONSES_AND_OFFERS,
    PROFILE_AND_CV,
    ADMIN_PANEL
}

enum class RegionFilter(val label: String, val icon: String) {
    ALL("All Regions", "🌐"),
    EUROPE("Europe Jobs", "🇪🇺"),
    GULF("Gulf Jobs", "🇸🇦")
}

object JobRegions {
    val EUROPE_COUNTRIES = listOf("Germany", "Netherlands", "Poland", "Sweden", "Austria", "United Kingdom", "France", "Ireland")
    val GULF_COUNTRIES = listOf("Saudi Arabia", "United Arab Emirates", "UAE", "Qatar", "Oman", "Kuwait", "Bahrain")

    fun isEurope(country: String): Boolean = EUROPE_COUNTRIES.any { country.contains(it, ignoreCase = true) }
    fun isGulf(country: String): Boolean = GULF_COUNTRIES.any { country.contains(it, ignoreCase = true) }
}

typealias JobNexaViewModel = GlobalHireViewModel

class GlobalHireViewModel(application: Application) : AndroidViewModel(application) {

    val repository: GlobalHireRepository

    val currentScreen = MutableStateFlow(Screen.HOME)
    val currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val searchQuery = MutableStateFlow("")
    val selectedRegionFilter = MutableStateFlow(RegionFilter.ALL)
    val selectedCountryFilter = MutableStateFlow("All Countries")
    val selectedCategoryFilter = MutableStateFlow("All")
    val selectedSponsorshipFilter = MutableStateFlow("All")
    val visaSponsorshipOnly = MutableStateFlow(false)

    fun selectRegion(region: RegionFilter) {
        selectedRegionFilter.value = region
        if (region == RegionFilter.EUROPE && JobRegions.isGulf(selectedCountryFilter.value)) {
            selectedCountryFilter.value = "All Countries"
        } else if (region == RegionFilter.GULF && JobRegions.isEurope(selectedCountryFilter.value)) {
            selectedCountryFilter.value = "All Countries"
        }
    }

    val authState: StateFlow<AuthState>
    val authLoading = MutableStateFlow(false)
    val authError = MutableStateFlow<String?>(null)
    val cloudStatusMessage = MutableStateFlow<String?>(null)
    val showAuthSheet = MutableStateFlow(false)
    val showAuthSheetInitialTab = MutableStateFlow(0) // 0: Sign In, 1: Sign Up, 2: Config
    val pendingJobToApply = MutableStateFlow<Job?>(null)
    val showDevDiagnostics = MutableStateFlow(false)

    val candidateProfile: StateFlow<CandidateProfile?>
    val allJobs: StateFlow<List<Job>>
    val allMatches: StateFlow<List<JobMatch>>
    val allApplications: StateFlow<List<JobApplication>>
    val allMessages: StateFlow<List<EmployerMessage>>
    val interviewInvitations: StateFlow<List<EmployerMessage>>
    val allOfferReviews: StateFlow<List<OfferReview>>
    val allSources: StateFlow<List<JobSource>>
    val allAuditLogs: StateFlow<List<AuditLog>>

    // Inspection sheets
    val selectedJobForDetail = MutableStateFlow<Job?>(null)
    val selectedApplicationForDetail = MutableStateFlow<JobApplication?>(null)
    val cvExtractionDialogData = MutableStateFlow<ExtractedCvData?>(null)
    val userNotification = MutableStateFlow<String?>(null)
    val signedCvDownloadUrl = MutableStateFlow<String?>(null)

    init {
        val db = AppDatabase.getDatabase(application)
        repository = GlobalHireRepository(db, application)

        authState = repository.authState

        viewModelScope.launch {
            repository.initializeIfNeeded()
        }

        candidateProfile = repository.candidateProfile.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            SeedData.getDefaultProfile()
        )

        allJobs = repository.allJobs.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allMatches = repository.allMatches.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allApplications = repository.allApplications.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allMessages = repository.allMessages.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        interviewInvitations = repository.interviewInvitations.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allOfferReviews = repository.allOfferReviews.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allSources = repository.allSources.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allAuditLogs = repository.allAuditLogs.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    // Filtered jobs combining search, country, sponsorship, and region
    val filteredJobs: StateFlow<List<Pair<Job, JobMatch?>>> = combine(
        combine(allJobs, allMatches, searchQuery) { jobs, matches, query ->
            Triple(jobs, matches, query)
        },
        combine(selectedCountryFilter, selectedSponsorshipFilter, selectedRegionFilter) { country, sponsorship, region ->
            Triple(country, sponsorship, region)
        }
    ) { (jobs, matches, query), (country, sponsorship, region) ->
        val matchMap = matches.associateBy { it.jobId }
        jobs.filter { job ->
            val matchQuery = query.isBlank() ||
                    job.title.contains(query, ignoreCase = true) ||
                    job.company.contains(query, ignoreCase = true) ||
                    job.description.contains(query, ignoreCase = true) ||
                    job.requiredLicences.contains(query, ignoreCase = true)

            val matchCountry = country == "All Countries" || job.country.equals(country, ignoreCase = true)

            val matchSponsorship = sponsorship == "All" ||
                    (sponsorship == "Verified Sponsor" && job.sponsorshipStatus == "Verified Sponsor") ||
                    (sponsorship == "Sponsorship Available" && job.sponsorshipStatus.contains("Sponsor"))

            val matchRegion = when (region) {
                RegionFilter.ALL -> true
                RegionFilter.EUROPE -> JobRegions.isEurope(job.country)
                RegionFilter.GULF -> JobRegions.isGulf(job.country)
            }

            matchQuery && matchCountry && matchSponsorship && matchRegion
        }.map { job ->
            Pair(job, matchMap[job.id])
        }.sortedByDescending { it.second?.overallScore ?: 0 }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiCvParserService = AiCvParserService()
    val aiExtractionLoading = MutableStateFlow(false)
    val cvParsingMethodUsed = MutableStateFlow<String?>(null)

    // Job Description Translation
    val aiTranslationService = AiTranslationService()
    val targetTranslationLanguage = MutableStateFlow(TranslationLanguageManager.getSavedOrDetectedLanguage(application))
    val isTranslatingJobDescription = MutableStateFlow(false)
    val activeJobTranslation = MutableStateFlow<TranslationResult?>(null)

    fun setTargetTranslationLanguage(language: String) {
        val clean = language.trim()
        if (clean.isNotBlank()) {
            targetTranslationLanguage.value = clean
            TranslationLanguageManager.saveTargetLanguage(getApplication(), clean)
            activeJobTranslation.value = null
        }
    }

    fun translateJobDescription(job: Job, targetLang: String = targetTranslationLanguage.value) {
        viewModelScope.launch {
            isTranslatingJobDescription.value = true
            val result = aiTranslationService.translateJobDescription(job.id, job.description, targetLang)
            activeJobTranslation.value = result
            isTranslatingJobDescription.value = false
            if (result is TranslationResult.Error) {
                userNotification.value = result.errorMessage
            }
        }
    }

    fun clearActiveJobTranslation() {
        activeJobTranslation.value = null
    }

    fun selectLanguage(lang: AppLanguage) {
        currentLanguage.value = lang
    }

    fun openSignIn() {
        showAuthSheetInitialTab.value = 0
        showAuthSheet.value = true
    }

    fun openSignUp() {
        showAuthSheetInitialTab.value = 1
        showAuthSheet.value = true
    }

    fun signUp(email: String, pass: String, fullName: String) {
        viewModelScope.launch {
            authLoading.value = true
            authError.value = null
            when (val res = repository.signUp(email, pass, fullName)) {
                is AuthResult.Success -> {
                    authLoading.value = false
                    userNotification.value = "Account created! Welcome to JobNexa AI, $fullName."
                    showAuthSheet.value = false
                    currentScreen.value = Screen.HOME
                    val pending = pendingJobToApply.value
                    if (pending != null) {
                        pendingJobToApply.value = null
                        selectedJobForDetail.value = pending
                    }
                }
                is AuthResult.Error -> {
                    authLoading.value = false
                    authError.value = res.message
                }
            }
        }
    }

    fun signIn(email: String, pass: String) {
        viewModelScope.launch {
            authLoading.value = true
            authError.value = null
            when (val res = repository.signIn(email, pass)) {
                is AuthResult.Success -> {
                    authLoading.value = false
                    userNotification.value = "Signed in successfully as $email."
                    showAuthSheet.value = false
                    currentScreen.value = Screen.HOME
                    val pending = pendingJobToApply.value
                    if (pending != null) {
                        pendingJobToApply.value = null
                        selectedJobForDetail.value = pending
                    }
                }
                is AuthResult.Error -> {
                    authLoading.value = false
                    authError.value = res.message
                }
            }
        }
    }

    fun applyToJob(context: Context, job: Job, notes: String = "") {
        val auth = authState.value
        if (auth !is AuthState.Authenticated && auth !is AuthState.SandboxDemo) {
            pendingJobToApply.value = job
            userNotification.value = "Please sign in or create an account to apply for this job."
            openSignIn()
            return
        }

        viewModelScope.launch {
            if (job.applicationMethod == "DIRECT_PARTNER_API") {
                val app = repository.recordDirectPartnerApplication(
                    job = job,
                    tailoredCv = "JobNexa Verified Candidate Dossier (${candidateProfile.value?.fullName})",
                    coverLetter = "Candidate expression of interest transmitted via JobNexa Partner API."
                )
                userNotification.value = "Application successfully submitted via JobNexa Partner Integration (Ref: ${app.submissionReferenceId})!"
                selectedJobForDetail.value = null
                currentScreen.value = Screen.MY_APPLICATIONS
            } else {
                repository.recordExternalApplicationStarted(job, notes)
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(job.sourceUrl)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (e: Exception) {
                    // Browser intent fallback
                }
                userNotification.value = "Redirected to official employer careers portal. Application recorded in My Applications."
                selectedJobForDetail.value = null
                currentScreen.value = Screen.MY_APPLICATIONS
            }
        }
    }

    fun parseCvDocument(rawText: String) {
        viewModelScope.launch {
            aiExtractionLoading.value = true
            when (val res = aiCvParserService.parseDocumentText(rawText, candidateProfile.value)) {
                is CvParseResult.Success -> {
                    aiExtractionLoading.value = false
                    cvParsingMethodUsed.value = res.extractionMethod
                    cvExtractionDialogData.value = res.extracted
                    userNotification.value = "Extracted profile details via ${res.extractionMethod}. Please review and confirm."
                }
                is CvParseResult.Error -> {
                    aiExtractionLoading.value = false
                    userNotification.value = res.message
                }
            }
        }
    }

    fun recoverPassword(email: String) {
        viewModelScope.launch {
            authLoading.value = true
            authError.value = null
            when (val res = repository.recoverPassword(email)) {
                is AuthResult.Success -> {
                    authLoading.value = false
                    userNotification.value = res.data
                }
                is AuthResult.Error -> {
                    authLoading.value = false
                    authError.value = res.message
                }
            }
        }
    }

    fun logOut() {
        viewModelScope.launch {
            repository.signOut()
            userNotification.value = "You have logged out."
        }
    }

    fun enterSandboxMode() {
        repository.enterSandboxDemoMode()
        showAuthSheet.value = false
        userNotification.value = "Switched to Standalone Sandbox Demo mode."
    }

    fun openAuthSheet() {
        showAuthSheet.value = true
    }

    fun closeAuthSheet() {
        showAuthSheet.value = false
        authError.value = null
    }

    fun setShowAuthSheet(show: Boolean) {
        showAuthSheet.value = show
        if (!show) authError.value = null
    }


    fun testCloudConnection() {
        viewModelScope.launch {
            cloudStatusMessage.value = "Testing Supabase REST and Auth endpoints..."
            val (ok, msg) = repository.testSupabaseHealth()
            cloudStatusMessage.value = msg
            userNotification.value = msg
        }
    }

    fun saveCustomCredentials(url: String, key: String) {
        repository.saveCustomSupabaseCredentials(url, key)
        userNotification.value = "Custom Supabase credentials saved."
        testCloudConnection()
    }

    // --- Private CV Storage ---

    fun uploadCvFile(fileName: String, bytes: ByteArray, mimeType: String = "application/pdf") {
        viewModelScope.launch {
            when (val res = repository.uploadCvToPrivateStorage(fileName, bytes, mimeType)) {
                is StorageUploadResult.Success -> {
                    userNotification.value = "CV uploaded to private storage: ${res.path}"
                    signedCvDownloadUrl.value = res.fullStorageUrl
                }
                is StorageUploadResult.Error -> {
                    userNotification.value = "CV Upload Error: ${res.message}"
                }
            }
        }
    }

    fun requestSignedCvDownload(storagePath: String) {
        viewModelScope.launch {
            val signedUrl = repository.getSignedCvDownloadUrl(storagePath)
            signedCvDownloadUrl.value = signedUrl
            if (signedUrl != null) {
                userNotification.value = "Generated temporary signed download URL (valid for 5 mins)."
            }
        }
    }

    // --- Navigation & Core Workflows ---

    fun navigateTo(screen: Screen) {
        currentScreen.value = screen
    }

    fun openJobDetail(job: Job) {
        selectedJobForDetail.value = job
        val cached = aiTranslationService.getCachedTranslation(job.id, targetTranslationLanguage.value)
        if (!cached.isNullOrBlank()) {
            activeJobTranslation.value = TranslationResult.Success(
                originalText = job.description,
                translatedText = cached,
                targetLanguage = targetTranslationLanguage.value,
                isCached = true
            )
        } else {
            activeJobTranslation.value = null
        }
    }

    fun closeJobDetail() {
        selectedJobForDetail.value = null
        activeJobTranslation.value = null
    }

    fun openApplicationDetail(app: JobApplication) {
        selectedApplicationForDetail.value = app
    }

    fun closeApplicationDetail() {
        selectedApplicationForDetail.value = null
    }

    fun showCvExtractionForReview(data: ExtractedCvData) {
        cvExtractionDialogData.value = data
    }

    fun dismissCvDialog() {
        cvExtractionDialogData.value = null
    }

    fun applyExtractedCvToProfile(data: ExtractedCvData) {
        val current = candidateProfile.value ?: SeedData.getDefaultProfile()
        val updated = current.copy(
            fullName = data.fullName,
            email = data.email,
            phone = data.phone,
            citizenship = data.citizenship,
            currentResidenceCountry = data.currentResidenceCountry,
            educationLevel = data.educationLevel,
            fieldOfStudy = data.fieldOfStudy,
            yearsExperience = data.yearsExperience,
            currentJobTitle = data.currentJobTitle,
            responsibilities = data.responsibilities,
            primaryIndustry = data.primaryIndustry,
            machineEquipment = data.machineEquipment,
            licences = data.licences,
            licenceIssuingCountry = data.licenceIssuingCountry,
            languages = data.languages,
            expectedSalaryMonthly = data.expectedSalaryMonthly,
            cvRawText = data.rawSummary,
            updatedAt = System.currentTimeMillis()
        )
        viewModelScope.launch {
            repository.updateProfile(updated)
            userNotification.value = "Candidate profile updated from CV! Matches recalculated."
            dismissCvDialog()
        }
    }

    fun updateProfile(profile: CandidateProfile) {
        viewModelScope.launch {
            repository.updateProfile(profile)
            userNotification.value = "Profile preferences saved successfully."
        }
    }

    fun toggleSaveJob(jobId: String, currentSaved: Boolean) {
        viewModelScope.launch {
            repository.toggleSaveJob(jobId, currentSaved)
        }
    }

    fun prepareApplicationForJob(jobId: String) {
        viewModelScope.launch {
            val app = repository.prepareApplication(jobId)
            if (app != null) {
                userNotification.value = "Application materials prepared! Review & authorize in Pipeline."
                currentScreen.value = Screen.APPLICATIONS_PIPELINE
            }
        }
    }

    fun approveAndSubmitApplication(appId: String) {
        viewModelScope.launch {
            repository.approveAndSubmitApplication(appId)
            userNotification.value = "Application successfully submitted with official reference code!"
            selectedApplicationForDetail.value = selectedApplicationForDetail.value?.copy(
                candidateApproved = true,
                status = "Submitted"
            )
        }
    }

    fun advanceApplicationStatus(appId: String, nextStatus: String) {
        viewModelScope.launch {
            repository.advanceApplicationStatus(appId, nextStatus)
            userNotification.value = "Application moved to '$nextStatus'."
            selectedApplicationForDetail.value = selectedApplicationForDetail.value?.copy(status = nextStatus)
        }
    }

    fun scanOfferDocument(
        company: String,
        role: String,
        country: String,
        salary: Double,
        currency: String,
        contractType: String,
        documentText: String,
        fileName: String
    ) {
        viewModelScope.launch {
            val review = OfferVerificationAgent.analyzeOfferDocument(
                companyName = company,
                roleTitle = role,
                country = country,
                monthlyGross = salary,
                currency = currency,
                contractType = contractType,
                documentText = documentText,
                documentFileName = fileName
            )
            repository.addOfferReview(review)
            userNotification.value = "Offer letter scanned: ${review.verificationOutcome} (Risk: ${review.riskScore}/100)"
        }
    }

    fun markMessageRead(id: String) {
        viewModelScope.launch {
            repository.markMessageRead(id)
        }
    }

    fun testSourceConnection(sourceId: String) {
        viewModelScope.launch {
            repository.testJobSourceConnection(sourceId)
            userNotification.value = "Pinged source gateway: Latency and vacancies refreshed."
        }
    }

    fun purgeCandidateData() {
        viewModelScope.launch {
            repository.purgeCandidateData()
            userNotification.value = "GDPR Data Purge complete. All private records reset."
        }
    }

    fun clearNotification() {
        userNotification.value = null
    }
}
