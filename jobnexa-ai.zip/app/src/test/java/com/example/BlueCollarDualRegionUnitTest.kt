package com.example

import com.example.data.seed.SeedData
import com.example.domain.JobMatchingAndVisaAgent
import com.example.ui.components.BlueCollarJobHelper
import com.example.ui.viewmodel.JobRegions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BlueCollarDualRegionUnitTest {

    @Test
    fun testDualRegionClassification() {
        // Europe verification
        assertTrue("Germany should be classified as Europe", JobRegions.isEurope("Germany"))
        assertTrue("Netherlands should be classified as Europe", JobRegions.isEurope("Netherlands"))
        assertTrue("Poland should be classified as Europe", JobRegions.isEurope("Poland"))
        assertTrue("Sweden should be classified as Europe", JobRegions.isEurope("Sweden"))
        assertTrue("Austria should be classified as Europe", JobRegions.isEurope("Austria"))
        assertFalse("Saudi Arabia is not Europe", JobRegions.isEurope("Saudi Arabia"))

        // Gulf verification
        assertTrue("Saudi Arabia should be classified as Gulf", JobRegions.isGulf("Saudi Arabia"))
        assertTrue("UAE should be classified as Gulf", JobRegions.isGulf("UAE"))
        assertTrue("United Arab Emirates should be classified as Gulf", JobRegions.isGulf("United Arab Emirates"))
        assertTrue("Qatar should be classified as Gulf", JobRegions.isGulf("Qatar"))
        assertFalse("Germany is not Gulf", JobRegions.isGulf("Germany"))
    }

    @Test
    fun testFinancialBreakdownEstimator() {
        val jobs = SeedData.getInitialJobs()

        // Gulf job: NEOM Heavy Bulldozer Driver (Saudi Arabia)
        val gulfJob = jobs.first { it.id == "job-sa-008" }
        val gulfBreakdown = BlueCollarJobHelper.calculateFinancialBreakdown(gulfJob)

        assertTrue(gulfBreakdown.isGulf)
        assertEquals("Gulf tax rate must be 0%", 0, gulfBreakdown.taxRatePercent)
        assertEquals("Gulf tax deduction must be 0", 0.0, gulfBreakdown.taxAmountMonthly, 0.01)
        assertTrue("Gulf jobs must feature employer-paid accommodation", gulfBreakdown.isHousingFree)
        assertEquals("Worker visa fee must be zero (Anti-Fraud Policy)", 0.0, gulfBreakdown.visaRelocationCostWorker, 0.01)
        assertTrue("Estimated net monthly savings must exceed 3000 for NEOM salary", gulfBreakdown.estimatedNetMonthlySavings > 3000.0)

        // Europe job: Strabag Heavy Excavator Operator (Germany)
        val europeJob = jobs.first { it.id == "job-de-001" }
        val europeBreakdown = BlueCollarJobHelper.calculateFinancialBreakdown(europeJob)

        assertFalse(europeBreakdown.isGulf)
        assertTrue("European tax rate must be greater than zero", europeBreakdown.taxRatePercent > 0)
        assertFalse("European jobs do not typically include free camp accommodation", europeBreakdown.isHousingFree)
        assertEquals("Candidate visa cost must be zero under direct apply", 0.0, europeBreakdown.visaRelocationCostWorker, 0.01)
        assertTrue("Europe net monthly savings must be calculated cleanly", europeBreakdown.estimatedNetMonthlySavings > 500.0)
    }

    @Test
    fun testMachineryRoleIcons() {
        assertEquals("🚜", BlueCollarJobHelper.getRoleMachineryIcon("Heavy Excavator Operator"))
        assertEquals("🚜", BlueCollarJobHelper.getRoleMachineryIcon("Bulldozer Driver CAT D11"))
        assertEquals("🏗️", BlueCollarJobHelper.getRoleMachineryIcon("Mobile Crane Operator"))
        assertEquals("🏗️", BlueCollarJobHelper.getRoleMachineryIcon("Offshore Rigging Specialist"))
        assertEquals("🚚", BlueCollarJobHelper.getRoleMachineryIcon("Haul Truck Driver Mining"))
        assertEquals("🔧", BlueCollarJobHelper.getRoleMachineryIcon("Hydraulic Plant Mechanic"))
        assertEquals("🛠️", BlueCollarJobHelper.getRoleMachineryIcon("Pipe Welder Structural"))
        assertEquals("⚙️", BlueCollarJobHelper.getRoleMachineryIcon("CNC & Mechatronics Tech"))
    }

    @Test
    fun testHeavyMachineryMatchingAlgorithm() {
        val candidate = SeedData.getDefaultProfile()
        val jobs = SeedData.getInitialJobs()

        // NEOM Bulldozer job should yield high match score for certified heavy machinery operator
        val bulldozerJob = jobs.first { it.id == "job-sa-008" }
        val matchResult = JobMatchingAndVisaAgent.calculateMatch(candidate, bulldozerJob)

        assertTrue(
            "Heavy machinery operator with CAT D10/D11 experience should have >= 75% match with NEOM Bulldozer job",
            matchResult.overallScore >= 75
        )
        assertTrue("Skill score should reflect machinery match", matchResult.skillScore >= 75)
        assertTrue("Licence score should reflect heavy plant operator credentials", matchResult.licenceScore >= 75)
        assertTrue(matchResult.matchExplanation.isNotBlank())
    }

    @Test
    fun testSeedJobsRegionDistribution() {
        val jobs = SeedData.getInitialJobs()
        val europeJobs = jobs.filter { JobRegions.isEurope(it.country) }
        val gulfJobs = jobs.filter { JobRegions.isGulf(it.country) }

        assertEquals("Should have exactly 14 seed jobs total", 14, jobs.size)
        assertEquals("Should have 7 Europe jobs", 7, europeJobs.size)
        assertEquals("Should have 7 Gulf jobs", 7, gulfJobs.size)

        // Verify all jobs specify Direct Apply or Official Portal with sourceUrl
        jobs.forEach { job ->
            assertTrue(
                "Job ${job.id} should have valid official apply url",
                job.sourceUrl.isNotBlank() && job.sourceUrl.startsWith("http")
            )
            assertTrue(
                "Job ${job.id} should designate a valid official visa authority",
                job.officialVisaSource.isNotBlank()
            )
        }
    }
}
