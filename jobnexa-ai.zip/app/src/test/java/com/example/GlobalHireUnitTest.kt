package com.example

import com.example.data.model.CandidateProfile
import com.example.data.model.Job
import com.example.data.seed.SeedData
import com.example.domain.ApplicationAutomationAgent
import com.example.domain.CvParserAgent
import com.example.domain.JobMatchingAndVisaAgent
import com.example.domain.OfferVerificationAgent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GlobalHireUnitTest {

    @Test
    fun testJobMatchingAndVisaCalculations() {
        val profile = SeedData.getDefaultProfile()
        val siemensJob = SeedData.getInitialJobs().first { it.company == "Siemens Mobility AG" }

        val match = JobMatchingAndVisaAgent.calculateMatch(profile, siemensJob)

        assertNotNull(match)
        assertTrue("Match score should be strong for matching profile (> 80%)", match.overallScore >= 80)
        assertTrue("Experience score should be high", match.experienceScore >= 90)
        assertTrue("Licence score should be high", match.licenceScore >= 80)
        assertEquals("Siemens job is in EUR", "EUR", match.currency)
        assertTrue("Estimated net salary should be positive", match.estimatedNetSalary > 0)
        assertTrue("Estimated savings should be positive", match.estimatedMonthlySavings > 0)
        assertTrue("Recognition should be required for German engineering", match.recognitionRequired)
    }

    @Test
    fun testCvExtractionAgent() {
        val sampleCv = CvParserAgent.sampleCvs.first()
        val extracted = sampleCv.data

        assertEquals("Alex Mercer", extracted.fullName)
        assertEquals(6, extracted.yearsExperience)
        assertTrue("Extracted equipment must contain CNC or PLC", extracted.machineEquipment.contains("CNC") || extracted.machineEquipment.contains("PLC"))
        assertTrue("Extracted licences must contain Code 95 or TÜV", extracted.licences.contains("Code 95") || extracted.licences.contains("TÜV"))
        assertTrue("Extracted languages must contain English", extracted.languages.contains("English"))
    }

    @Test
    fun testApplicationWorkflowAndCandidateApproval() {
        val profile = SeedData.getDefaultProfile()
        val job = SeedData.getInitialJobs().first()

        // Prepare application
        val app = ApplicationAutomationAgent.prepareApplication(profile, job)
        assertEquals("Application Prepared", app.status)
        assertFalse("Candidate must NOT be marked approved prior to explicit consent", app.candidateApproved)
        assertTrue("Tailored CV must contain candidate name", app.tailoredCvContent.contains(profile.fullName))
        assertTrue("Cover letter must contain target company", app.tailoredCoverLetter.contains(job.company))

        // Candidate approves & submits
        val submitted = ApplicationAutomationAgent.submitApplication(app)
        assertEquals("Submitted", submitted.status)
        assertTrue("Candidate must be marked approved after submission", submitted.candidateApproved)
        assertNotNull(submitted.submissionReferenceId)
        assertTrue("Submission ref must begin with JN-", submitted.submissionReferenceId!!.startsWith("JN-"))
    }

    @Test
    fun testOfferVerificationFraudGuard() {
        // Test Genuine Offer
        val genuineReview = OfferVerificationAgent.analyzeOfferDocument(
            companyName = "Rotterdam World Gateway",
            roleTitle = "Logistics Supervisor",
            country = "Netherlands",
            monthlyGross = 4500.0,
            currency = "EUR",
            contractType = "Permanent",
            documentText = "Formal employment offer. Employer covers all IND sponsorship fees. No charges to employee.",
            documentFileName = "rwg_offer.pdf"
        )
        assertEquals("AUTHENTIC_VERIFIED", genuineReview.verificationOutcome)
        assertTrue("Risk score should be low for genuine offer", genuineReview.riskScore < 30)

        // Test Scam Offer with upfront visa fee
        val scamReview = OfferVerificationAgent.analyzeOfferDocument(
            companyName = "Fake Recruiting Agency LLC",
            roleTitle = "Operations Manager",
            country = "United Arab Emirates",
            monthlyGross = 18000.0,
            currency = "EUR",
            contractType = "Contract",
            documentText = "Congratulations! Please send $850 USD processing fee via wire transfer / Western Union to our visa agent. Contact: recruiter@gmail.com",
            documentFileName = "suspicious_letter.pdf"
        )
        assertEquals("SUSPICIOUS_DETAILS", scamReview.verificationOutcome)
        assertTrue("Risk score should be high for advance-fee scam", scamReview.riskScore >= 70)
        assertTrue("Fee policy must flag the illegal payment requirement", scamReview.feePolicyNotice.contains("HIGH RISK") || scamReview.feePolicyNotice.contains("Never transfer funds"))
    }
}
