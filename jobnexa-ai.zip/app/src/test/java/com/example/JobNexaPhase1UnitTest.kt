package com.example

import com.example.data.model.CandidateProfile
import com.example.data.remote.supabase.AuthResult
import com.example.data.remote.supabase.AuthUser
import com.example.data.remote.supabase.SupabaseConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class JobNexaPhase1UnitTest {

    @Test
    fun testSupabaseConfigValidation() {
        val configured = SupabaseConfig.isConfigured(null)
        if (configured) {
            val url = SupabaseConfig.getSupabaseUrl(null)
            val key = SupabaseConfig.getSupabaseAnonKey(null)
            assertTrue("Configured URL must be a valid Supabase host", url.startsWith("https://") && url.contains(".supabase.co"))
            assertTrue("Configured Key must be valid length", key.length > 20)
        }

        // Test explicit URL and key structure validation
        val validUrl = "https://xyzcompany.supabase.co"
        val validKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.dummy_anon_key"
        assertTrue(validUrl.startsWith("https://") && validUrl.contains(".supabase.co"))
        assertTrue(validKey.startsWith("eyJ") && validKey.length > 20)

        val invalidUrl = "not-a-url"
        val invalidKey = "short"
        assertFalse(invalidUrl.startsWith("https://") && invalidUrl.contains(".supabase.co"))
        assertFalse(invalidKey.length > 20)
    }

    @Test
    fun testCandidateTenantIsolation() {
        // Verify User A and User B profiles remain partitioned by User ID
        val userA = AuthUser(id = "user-uuid-1111", email = "alex@globalhire.ai")
        val userB = AuthUser(id = "user-uuid-2222", email = "elena@jobnexa.com")

        val profileA = CandidateProfile(
            userId = userA.id,
            fullName = "Alex Mercer",
            currentJobTitle = "Senior Robotics Maintenance Technician"
        )

        val profileB = CandidateProfile(
            userId = userB.id,
            fullName = "Elena Rostova",
            currentJobTitle = "Bilingual Logistics & Fleet Dispatcher"
        )

        assertEquals("user-uuid-1111", profileA.userId)
        assertEquals("user-uuid-2222", profileB.userId)
        assertFalse("Profiles for different users must never share tenant user IDs", profileA.userId == profileB.userId)
    }

    @Test
    fun testCvStorageFileValidationAndPath() {
        val userId = "user-uuid-1111"
        val fileName = "cv_march_2026.pdf"

        // Path generation under private Zero-Trust bucket
        val privatePath = "$userId/$fileName"
        assertEquals("user-uuid-1111/cv_march_2026.pdf", privatePath)
        assertTrue("Storage path must be prefixed with user ID for RLS folder isolation", privatePath.startsWith("$userId/"))

        // File size limit checks (10MB)
        val maxAllowedBytes = 10 * 1024 * 1024
        val sampleValidBytes = ByteArray(500 * 1024) // 500 KB
        val sampleOversizedBytes = ByteArray(12 * 1024 * 1024) // 12 MB

        assertTrue("500KB file is within 10MB limit", sampleValidBytes.size <= maxAllowedBytes)
        assertFalse("12MB file exceeds 10MB limit", sampleOversizedBytes.size <= maxAllowedBytes)

        // MIME type validation
        val allowedMimeTypes = listOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword")
        assertTrue(allowedMimeTypes.contains("application/pdf"))
        assertFalse(allowedMimeTypes.contains("application/x-executable"))
        assertFalse(allowedMimeTypes.contains("application/x-sh"))
    }

    @Test
    fun testSqlMigrationSchemaRlsIntegrity() {
        // Read the migration file from project directory (works in both root and app execution directories)
        val migrationFile = listOf(
            File("supabase/migrations/20261025000000_jobnexa_schema.sql"),
            File("../supabase/migrations/20261025000000_jobnexa_schema.sql")
        ).firstOrNull { it.exists() }
        assertNotNull("Supabase SQL migration file must exist in supabase/migrations/", migrationFile)

        val sqlContent = migrationFile!!.readText()
        assertTrue("Must enable Row Level Security on candidate_profiles", sqlContent.contains("ALTER TABLE public.candidate_profiles ENABLE ROW LEVEL SECURITY;"))
        assertTrue("Must create private candidate_documents storage bucket", sqlContent.contains("candidate_documents"))
        assertTrue("Storage bucket must NOT be public", sqlContent.contains("VALUES ('candidate_documents', 'candidate_documents', false)") && sqlContent.contains("public = false"))
        assertTrue("Must have folder RLS for candidate storage", sqlContent.contains("(storage.foldername(name))[1] = auth.uid()::text"))
    }

    @Test
    fun testPasswordRecoveryRequirements() {
        val validEmail = "candidate@jobnexa.com"
        val invalidEmail = "not-an-email"

        val isValid = validEmail.contains("@") && validEmail.contains(".")
        val isInvalid = invalidEmail.contains("@") && invalidEmail.contains(".")

        assertTrue("Valid email must pass format check", isValid)
        assertFalse("Invalid email must fail format check", isInvalid)
    }
}
