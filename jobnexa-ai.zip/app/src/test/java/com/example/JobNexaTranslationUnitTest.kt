package com.example

import com.example.domain.AiTranslationService
import com.example.domain.TranslationLanguageManager
import com.example.domain.TranslationResult
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.JobNexaStrings
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class JobNexaTranslationUnitTest {

    @Test
    fun testEnglishOnlyAppInterfaceStrings() {
        val strings = listOf(
            JobNexaStrings.navHome(),
            JobNexaStrings.navSearch(),
            JobNexaStrings.navApplications(),
            JobNexaStrings.navProfile(),
            JobNexaStrings.signIn(),
            JobNexaStrings.signUp(),
            JobNexaStrings.signOut(),
            JobNexaStrings.viewJob(),
            JobNexaStrings.applyNow(),
            JobNexaStrings.searchPlaceholder(),
            JobNexaStrings.verifiedVacanciesTitle(),
            JobNexaStrings.noApplicationsYet(),
            JobNexaStrings.findJobsPrompt()
        )

        for (text in strings) {
            assertTrue("String '$text' must not be blank", text.isNotBlank())
            // Assert all characters are Latin/standard ASCII (pure English, no Arabic/Devanagari/Urdu scripts)
            val hasNonLatinScript = text.any { it.code > 0x024F }
            assertFalse("UI interface string '$text' must be English-only without non-Latin localization scripts", hasNonLatinScript)
        }

        assertEquals("Home", JobNexaStrings.navHome())
        assertEquals("Search Jobs", JobNexaStrings.navSearch())
        assertEquals("My Applications", JobNexaStrings.navApplications())
        assertEquals("Profile", JobNexaStrings.navProfile())
        assertEquals("Sign In", JobNexaStrings.signIn())
        assertEquals("Sign Up", JobNexaStrings.signUp())
        assertEquals("Apply Now", JobNexaStrings.applyNow())
    }

    @Test
    fun testDeviceLanguageDetectionNames() {
        // Test display names across multiple global locales
        val spanishLocale = Locale.forLanguageTag("es-ES")
        assertEquals("Spanish", spanishLocale.getDisplayLanguage(Locale.ENGLISH))

        val germanLocale = Locale.forLanguageTag("de-DE")
        assertEquals("German", germanLocale.getDisplayLanguage(Locale.ENGLISH))

        val frenchLocale = Locale.forLanguageTag("fr-FR")
        assertEquals("French", frenchLocale.getDisplayLanguage(Locale.ENGLISH))

        val arabicLocale = Locale.forLanguageTag("ar-SA")
        assertEquals("Arabic", arabicLocale.getDisplayLanguage(Locale.ENGLISH))

        val hindiLocale = Locale.forLanguageTag("hi-IN")
        assertEquals("Hindi", hindiLocale.getDisplayLanguage(Locale.ENGLISH))

        val urduLocale = Locale.forLanguageTag("ur-PK")
        assertEquals("Urdu", urduLocale.getDisplayLanguage(Locale.ENGLISH))

        val tagalogLocale = Locale.forLanguageTag("tl-PH")
        assertEquals("Tagalog", tagalogLocale.getDisplayLanguage(Locale.ENGLISH))

        val englishLocale = Locale.forLanguageTag("en-US")
        assertEquals("English", englishLocale.getDisplayLanguage(Locale.ENGLISH))
    }

    @Test
    fun testTranslationCachingMechanism() = runBlocking {
        val service = AiTranslationService()
        val jobId = "job-eu-8821"
        val originalText = "Supervise automated sorting line and maintain Siemens robotic palletizers."
        val translatedSpanish = "Supervisar la línea de clasificación automatizada y mantener los paletizadores robóticos Siemens."
        val translatedFrench = "Superviser la ligne de tri automatisée et entretenir les palettiseurs robotiques Siemens."

        // Preload cache for Spanish
        service.putInCache(jobId, "Spanish", translatedSpanish)

        // Querying Spanish translation should return cached result immediately
        val resultSpanish = service.translateJobDescription(jobId, originalText, "Spanish")
        assertTrue("Spanish result must be Success", resultSpanish is TranslationResult.Success)
        val successSpanish = resultSpanish as TranslationResult.Success
        assertEquals(translatedSpanish, successSpanish.translatedText)
        assertEquals(originalText, successSpanish.originalText)
        assertEquals("Spanish", successSpanish.targetLanguage)
        assertTrue("Must be marked as cached", successSpanish.isCached)

        // Preload cache for French
        service.putInCache(jobId, "French", translatedFrench)

        // Querying French translation should return French cached result
        val resultFrench = service.translateJobDescription(jobId, originalText, "French")
        assertTrue("French result must be Success", resultFrench is TranslationResult.Success)
        val successFrench = resultFrench as TranslationResult.Success
        assertEquals(translatedFrench, successFrench.translatedText)
        assertEquals("French", successFrench.targetLanguage)
        assertTrue("French result must be marked as cached", successFrench.isCached)
    }

    @Test
    fun testEnglishTargetLanguageBypassesTranslation() = runBlocking {
        val service = AiTranslationService()
        val jobId = "job-gulf-3411"
        val originalText = "Heavy equipment operator required for NEOM mega project. Housing and health insurance provided."

        val result = service.translateJobDescription(jobId, originalText, "English")
        assertTrue("Result for English target language must be Success", result is TranslationResult.Success)
        val success = result as TranslationResult.Success
        assertEquals("Target language English returns original text directly", originalText, success.translatedText)
        assertEquals(originalText, success.originalText)
        assertEquals("English", success.targetLanguage)
    }

    @Test
    fun testTranslationFailurePreservesOriginalText() = runBlocking {
        val service = AiTranslationService()
        val jobId = "job-de-1092"
        val originalText = "CNC Machinist for high-precision components in Stuttgart, Germany. 35 hours per week."

        // Without GEMINI_API_KEY configured in test JVM environment, service gracefully reports error
        val result = service.translateJobDescription(jobId, originalText, "Swedish")

        assertTrue("Result without API key must be Error", result is TranslationResult.Error)
        val error = result as TranslationResult.Error
        assertEquals("Original text must be strictly preserved in error result", originalText, error.originalText)
        assertEquals("Swedish", error.targetLanguage)
        assertTrue("Error message must explain credentials/service failure", error.errorMessage.contains("credentials") || error.errorMessage.contains("failed"))
    }

    @Test
    fun testSupportForArbitraryLanguages() {
        val popularList = TranslationLanguageManager.POPULAR_LANGUAGES
        assertTrue("Popular list must include Spanish", popularList.contains("Spanish"))
        assertTrue("Popular list must include Arabic", popularList.contains("Arabic"))
        assertTrue("Popular list must include Hindi", popularList.contains("Hindi"))
        assertTrue("Popular list must include Urdu", popularList.contains("Urdu"))
        assertTrue("Popular list must include Tagalog", popularList.contains("Tagalog"))
        assertTrue("Popular list must include German", popularList.contains("German"))
        assertTrue("Popular list must include French", popularList.contains("French"))

        // Any arbitrary language name can be passed to translation service (not limited to enum)
        val arbitraryLanguages = listOf("Swahili", "Vietnamese", "Amharic", "Greek", "Polish", "Korean", "Thai")
        for (lang in arbitraryLanguages) {
            assertTrue("Language name '$lang' is valid string", lang.isNotBlank())
        }
    }
}
