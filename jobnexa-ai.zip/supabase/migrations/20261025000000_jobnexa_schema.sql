-- JobNexa AI — Cloud Database Schema & Security Migrations
-- Target Database: Supabase PostgreSQL (GoTrue Auth, PostgREST, and Private Storage)
-- Enforces zero-trust Row Level Security (RLS) isolating each candidate's records.

-- Enable UUID extension if not enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. CANDIDATE PROFILES TABLE
-- Directly mapped 1:1 with auth.users to ensure strict isolation
CREATE TABLE IF NOT EXISTS public.candidate_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    citizenship TEXT,
    current_residence_country TEXT,
    current_permit_status TEXT,
    age_range TEXT,
    education_level TEXT,
    field_of_study TEXT,
    years_experience INT DEFAULT 0,
    current_job_title TEXT,
    responsibilities TEXT,
    primary_industry TEXT,
    machine_equipment TEXT,
    licences TEXT,
    licence_issuing_country TEXT,
    languages TEXT,
    preferred_countries TEXT,
    preferred_cities TEXT,
    expected_salary_monthly NUMERIC(10, 2) DEFAULT 0.0,
    currency TEXT DEFAULT 'EUR',
    willing_to_relocate BOOLEAN DEFAULT true,
    accommodation_required BOOLEAN DEFAULT false,
    availability_date TEXT,
    cv_file_name TEXT,
    cv_storage_path TEXT,
    cv_raw_text TEXT,
    intro_video_url TEXT,
    consent_accepted BOOLEAN DEFAULT true,
    auto_application_enabled BOOLEAN DEFAULT false,
    max_applications_per_day INT DEFAULT 5,
    excluded_employers TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS) on candidate_profiles
ALTER TABLE public.candidate_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Candidates can view only their own profile"
    ON public.candidate_profiles
    FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Candidates can insert their own profile"
    ON public.candidate_profiles
    FOR INSERT
    WITH CHECK (auth.uid() = id);

CREATE POLICY "Candidates can update their own profile"
    ON public.candidate_profiles
    FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

CREATE POLICY "Candidates can delete their own profile"
    ON public.candidate_profiles
    FOR DELETE
    USING (auth.uid() = id);


-- 2. CANDIDATE APPLICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.candidate_applications (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    job_id TEXT NOT NULL,
    job_title TEXT NOT NULL,
    company TEXT NOT NULL,
    country TEXT NOT NULL,
    city TEXT NOT NULL,
    salary_display TEXT,
    status TEXT NOT NULL DEFAULT 'Discovered',
    applied_timestamp BIGINT NOT NULL,
    tailored_cv_content TEXT,
    tailored_cover_letter TEXT,
    submission_method TEXT DEFAULT 'Guided Portal Assistant',
    submission_reference_id TEXT,
    candidate_approved BOOLEAN DEFAULT false,
    portal_direct_url TEXT,
    candidate_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.candidate_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own applications"
    ON public.candidate_applications
    FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);


-- 3. SAVED JOBS TABLE
CREATE TABLE IF NOT EXISTS public.saved_jobs (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    job_id TEXT NOT NULL,
    saved_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, job_id)
);

ALTER TABLE public.saved_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own saved jobs"
    ON public.saved_jobs
    FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);


-- 4. EMPLOYER MESSAGES TABLE
CREATE TABLE IF NOT EXISTS public.employer_messages (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    application_id TEXT NOT NULL,
    company TEXT NOT NULL,
    role_title TEXT NOT NULL,
    sender_name TEXT NOT NULL,
    sender_email TEXT NOT NULL,
    received_date TEXT NOT NULL,
    category TEXT NOT NULL,
    subject TEXT NOT NULL,
    body_snippet TEXT NOT NULL,
    interview_date TEXT,
    interview_timezone TEXT,
    interview_link TEXT,
    interview_format TEXT,
    requires_action BOOLEAN DEFAULT false,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.employer_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own employer messages"
    ON public.employer_messages
    FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);


-- 5. OFFER REVIEWS TABLE
CREATE TABLE IF NOT EXISTS public.offer_reviews (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    application_id TEXT,
    company_name TEXT NOT NULL,
    role_title TEXT NOT NULL,
    country TEXT NOT NULL,
    monthly_gross_offered NUMERIC(10, 2) NOT NULL,
    currency TEXT DEFAULT 'EUR',
    contract_type TEXT NOT NULL,
    uploaded_document_name TEXT NOT NULL,
    verification_outcome TEXT NOT NULL,
    risk_score INT NOT NULL,
    official_registry_check TEXT NOT NULL,
    fee_policy_notice TEXT NOT NULL,
    key_terms_summary TEXT NOT NULL,
    recommended_actions TEXT NOT NULL,
    reviewed_timestamp BIGINT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.offer_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view and create their own offer reviews"
    ON public.offer_reviews
    FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);


-- 6. PRIVATE STORAGE BUCKET: candidate_documents
-- Ensures CVs, passports, and certifications are private and access-controlled
INSERT INTO storage.buckets (id, name, public)
VALUES ('candidate_documents', 'candidate_documents', false)
ON CONFLICT (id) DO UPDATE SET public = false;

-- Storage RLS: Candidate can only access files inside their own user_id folder: candidate_documents/{user_id}/*
CREATE POLICY "Candidates can upload documents into their own folder"
    ON storage.objects
    FOR INSERT
    TO authenticated
    WITH CHECK (
        bucket_id = 'candidate_documents' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Candidates can view and download their own documents"
    ON storage.objects
    FOR SELECT
    TO authenticated
    USING (
        bucket_id = 'candidate_documents' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Candidates can delete their own documents"
    ON storage.objects
    FOR DELETE
    TO authenticated
    USING (
        bucket_id = 'candidate_documents' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );
