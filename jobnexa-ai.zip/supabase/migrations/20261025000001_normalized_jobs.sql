-- JobNexa AI — Normalized Job Listings & Provider Sources Migration
-- Extends the Supabase schema with normalized job records and verification timestamps

CREATE TABLE IF NOT EXISTS public.normalized_jobs (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    company TEXT NOT NULL,
    country TEXT NOT NULL,
    city TEXT NOT NULL,
    source_name TEXT NOT NULL,
    source_url TEXT NOT NULL,
    provider_job_id TEXT,
    publication_date TEXT,
    employment_type TEXT DEFAULT 'Full-time',
    gross_salary_monthly NUMERIC(10, 2) DEFAULT 0.0,
    currency TEXT DEFAULT 'EUR',
    min_years_experience INT DEFAULT 0,
    required_qualifications TEXT,
    required_licences TEXT,
    required_languages TEXT,
    sponsorship_status TEXT DEFAULT 'Unverified',
    application_method TEXT DEFAULT 'EXTERNAL_PORTAL',
    verification_status TEXT DEFAULT 'VERIFIED_PROVIDER_FEED',
    description TEXT,
    visa_track TEXT,
    official_visa_source TEXT,
    official_visa_url TEXT,
    last_verified_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Public read access for vacancies (jobs are public listings)
ALTER TABLE public.normalized_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view normalized job vacancies"
    ON public.normalized_jobs
    FOR SELECT
    TO authenticated, anon
    USING (true);

-- Index frequently searched attributes for fast querying
CREATE INDEX IF NOT EXISTS idx_jobs_country ON public.normalized_jobs(country);
CREATE INDEX IF NOT EXISTS idx_jobs_verification ON public.normalized_jobs(verification_status);
CREATE INDEX IF NOT EXISTS idx_jobs_sponsorship ON public.normalized_jobs(sponsorship_status);
CREATE INDEX IF NOT EXISTS idx_jobs_source ON public.normalized_jobs(source_name);
